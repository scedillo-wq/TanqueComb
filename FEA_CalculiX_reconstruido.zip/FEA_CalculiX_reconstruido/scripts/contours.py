"""Figuras de contorno (von Mises LC5 y rango por 1g) en el estilo de la memoria."""
import sys, json, numpy as np
from PIL import Image, ImageDraw, ImageFont
from viz import mesh_tris, raster, turbo, colorbar, FONT_B, FONT_R

def nodal_field(conn, etype, plate, val):
    """Promedio nodal por plancha (evita mezclar planchas en las uniones)."""
    acc = {}; cnt = {}
    for k in range(len(conn)):
        nn = 8 if etype[k] == 'S8R' else 6
        for n in conn[k][:nn]:
            key = (int(n), int(plate[k]))
            acc[key] = acc.get(key, 0) + val[k]; cnt[key] = cnt.get(key, 0) + 1
    return {k: acc[k]/cnt[k] for k in acc}

def render_field(tag, field, vmax, title, sub, hide_cats=('techo',), hide_names=(), azim=-50, elev=24, W=1000, H=900,
                 frame=((-10, -320, -360), (2480, 1330, 2420))):
    M = np.load(f'runs/{tag}_mesh.npz'); D = json.load(open(f'runs/{tag}_design.json'))
    cats = [p['cat'] for p in D['plates']]; names = [p['name'] for p in D['plates']]
    conn, etype, plate, nodes = M['conn'], M['etype'], M['plate'], M['nodes']
    val = np.load(f'runs/{tag}_{field}.npy')
    mask = np.array([not (cats[p] in hide_cats or names[p] in hide_names) for p in plate])
    nf = nodal_field(conn, etype, plate, val)
    tris, own = mesh_tris(nodes, conn, etype, mask)
    # color por triángulo: promedio de los dos nodos de borde + valor del elemento
    cols = []
    # reconstruir índices de nodos de cada triángulo (mismo orden que mesh_tris)
    for k in np.unique(own):
        pass
    vals = []
    order = {}
    for k in range(len(conn)):
        if not mask[k]: continue
        c = [int(x) for x in conn[k]]
        p = int(plate[k])
        if etype[k] == 'S8R':
            seq = [(c[0], c[4]), (c[4], c[1]), (c[1], c[5]), (c[5], c[2]), (c[2], c[6]), (c[6], c[3]), (c[3], c[7]), (c[7], c[0])]
        else:
            seq = [(c[0], c[3]), (c[3], c[1]), (c[1], c[4]), (c[4], c[2]), (c[2], c[5]), (c[5], c[0])]
        for a, b in seq:
            vals.append((nf[(a, p)] + nf[(b, p)] + val[k])/3)
    vals = np.array(vals)
    cols = turbo(vals/vmax)
    im, scr = raster(tris, cols, azim=azim, elev=elev, W=W, H=H, frame=frame, shade_min=0.75)
    d = ImageDraw.Draw(im)
    d.text((20, 14), title, font=ImageFont.truetype(FONT_B, 30), fill=(20, 20, 20))
    d.text((20, 54), sub, font=ImageFont.truetype(FONT_R, 22), fill=(70, 70, 70))
    return im

if __name__ == '__main__':
    pass
