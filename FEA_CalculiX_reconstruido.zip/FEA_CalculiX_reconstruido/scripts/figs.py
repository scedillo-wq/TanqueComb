"""Figuras para la memoria: modelos P3/P4, gráfico de resistencia y contornos."""
import json, os, sys
import numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image, ImageDraw, ImageFont
from viz import mesh_tris, raster, turbo, colorbar, FONT_B, FONT_R
from contours import nodal_field

OUT = 'figs'; os.makedirs(OUT, exist_ok=True)
R = json.load(open('runs/results.json'))
FRAME = ((-10, -320, -360), (2480, 1330, 2420))
plt.rcParams['font.family'] = 'Liberation Sans'

GREY = (0.62, 0.64, 0.68); ORANGE = (0.90, 0.47, 0.12); BLUE = (0.36, 0.62, 0.85); YELLOW = (0.95, 0.80, 0.25)
INK = '#1B222A'; MUTED = '#5F666D'


def load(tag):
    M = np.load(f'runs/{tag}_mesh.npz'); D = json.load(open(f'runs/{tag}_design.json'))
    return M, D


def geom_panel(tag, mode, title):
    M, D = load(tag)
    P = D['plates']; names = [p['name'] for p in P]; cats = [p['cat'] for p in P]
    def col(i):
        c = cats[i]
        if c == 'mamparo': return BLUE
        if c == 'diafragma': return YELLOW
        if P[i].get('new'): return ORANGE
        return GREY
    if mode == 'ext':
        mask = np.array([cats[p] not in ('mamparo',) for p in M['plate']])
        azim, elev = -50, 24
    else:
        hide = ('EXT_POST_CARA', 'EXT_POST_CHAFLAN', 'EXT_POST_EXTERIOR', 'EXT_LAT_EXTERIOR', 'EXT_LAT_FRONTAL',
                'PARED_POSTERIOR', 'PATCH_LUG_R')
        mask = np.array([not (cats[p] == 'techo' or names[p] in hide) for p in M['plate']])
        azim, elev = -50, 24
    tris, own = mesh_tris(M['nodes'], M['conn'], M['etype'], mask)
    cols = np.array([col(M['plate'][k]) for k in own])
    im, _ = raster(tris, cols, azim=azim, elev=elev, W=900, H=820, frame=FRAME)
    d = ImageDraw.Draw(im)
    d.text((14, 10), title, font=ImageFont.truetype(FONT_B, 28), fill=(20, 20, 20))
    return im


def fig_models():
    ims = [geom_panel('P3', 'ext', 'P3 - vista posterior-externa'), geom_panel('P4', 'ext', 'P4 - vista posterior-externa'),
           geom_panel('P3', 'cut', 'P3 - interior (sin cara nueva ni techo)'), geom_panel('P4', 'cut', 'P4 - interior (sin caras nuevas ni techo)')]
    w, h = ims[0].size
    g = Image.new('RGB', (w*2, 2*h + 120), 'white')
    for i, im in enumerate(ims): g.paste(im, ((i % 2)*w, (i//2)*h))
    d = ImageDraw.Draw(g); f = ImageFont.truetype(FONT_R, 30)
    x = 20; y = 2*h + 30
    for k, (c, lab) in enumerate(((GREY, 'Plancha existente'), (ORANGE, 'Plancha nueva'), (YELLOW, 'Pared original como diafragma'), (BLUE, 'Rompeolas'))):
        d.rectangle([x, y, x+34, y+30], fill=tuple(int(255*t) for t in c)); d.text((x+44, y-1), lab, font=f, fill=(40, 40, 40)); x += 60 + d.textlength(lab, font=f) + 30
    g.save(f'{OUT}/modelos_P3_P4.png')


def fig_chart():
    lcs = ['LC1', 'LC2', 'LC3', 'LC4', 'LC5']
    des = [('B0', 'B0 (reconstruido)', '#B4B2A6'), ('P3', 'P3', '#1baf7a'), ('P4', 'P4', '#6250d6')]
    fig, ax = plt.subplots(figsize=(10, 5.4), dpi=200)
    wbar = 0.26
    for j, (d, lab, c) in enumerate(des):
        vals = [R[d]['lc250'][k] for k in lcs]
        xs = np.arange(5) + (j-1)*wbar
        ax.bar(xs, vals, wbar*0.92, color=c, label=lab, zorder=3)
        for x, v in zip(xs, vals):
            ax.text(x, v+3, f'{v:.0f}', ha='center', va='bottom', fontsize=10.5, color=INK)
    ax.axhline(245/1.5, ls=(0, (4, 3)), color='#7A7A7A', lw=1.4, zorder=2)
    ax.text(-0.45, 245/1.5+4, 'Límite FS 1.5 = 163 MPa', fontsize=11, color=MUTED)
    ax.set_xticks(range(5)); ax.set_xticklabels(lcs, fontsize=12, color=INK)
    ax.set_ylim(0, 250); ax.set_ylabel('')
    ax.text(-0.04, 1.0, 'MPa', transform=ax.transAxes, fontsize=11, color=MUTED, ha='right', va='bottom')
    ax.grid(axis='y', color='#E6E6E6', lw=0.8, zorder=0); ax.set_axisbelow(True)
    for s_ in ('top', 'right', 'left'): ax.spines[s_].set_visible(False)
    ax.spines['bottom'].set_color('#BDBDBD'); ax.tick_params(axis='y', colors=MUTED, labelsize=10, length=0)
    ax.tick_params(axis='x', length=0)
    p3, p4, b0 = R['P3']['lc250']['LC5'], R['P4']['lc250']['LC5'], R['B0']['lc250']['LC5']
    fig.text(0.015, 0.955, f'A 3g, P3 y P4 suben el esfuerzo máximo {(p3/b0-1)*100:.0f} % y {(p4/b0-1)*100:.0f} % sobre el tanque actual ({b0:.0f} → {p3:.0f} y {p4:.0f} MPa)',
             fontsize=14, fontweight='bold', color=INK)
    fig.text(0.015, 0.905, 'von Mises máx. en tensión plana, fuera de 250 mm de los apoyos (MPa) · modelo reconstruido',
             fontsize=10.5, color=MUTED)
    ax.legend(loc='upper left', bbox_to_anchor=(0.0, 1.0), ncol=3, frameon=False, fontsize=11)
    fig.text(0.015, 0.02, 'LC1 1g · LC2 1g ± 0.5g long. · LC3 1g ± 0.5g lat. · LC4 2g + 0.5g long. + 0.3g lat. · LC5 3g vertical', fontsize=10, color=MUTED)
    plt.subplots_adjust(left=0.08, right=0.99, top=0.80, bottom=0.12)
    fig.savefig(f'{OUT}/resistencia_P3_P4.png'); plt.close(fig)


def fig_chart_all():
    des = ['B0', 'P1', 'P2', 'P1-M', 'P2-M', 'P3', 'P4']
    col = {'B0': '#B4B2A6', 'P1': '#eb6834', 'P2': '#f2a37f', 'P1-M': '#2a78d6', 'P2-M': '#8db8ec', 'P3': '#1baf7a', 'P4': '#6250d6'}
    b0 = R['B0']['lc250']['LC5']
    fig, ax = plt.subplots(figsize=(10, 4.6), dpi=200)
    ys = np.arange(len(des))[::-1]
    for y, d in zip(ys, des):
        v = R[d]['lc250']['LC5']; v3 = R[d]['lc250_3d']['LC5']
        ax.barh(y, v, 0.62, color=col[d], zorder=3)
        lab = f'{v:.0f} MPa · FS {245/v:.2f}' + ('' if d == 'B0' else f' · {(v/b0-1)*100:+.0f} % vs B0')
        ax.text(v+3, y, lab, va='center', fontsize=10.5, color=INK)
        ax.plot([v3, v3], [y-0.31, y+0.31], color=INK, lw=1.6, zorder=4)
    ax.axvline(245/1.5, ls=(0, (4, 3)), color='#7A7A7A', lw=1.3, zorder=2)
    ax.text(245/1.5+2, ys[0]+0.55, 'FS 1.5', fontsize=10, color=MUTED)
    ax.axvline(245, color='#C92A2A', lw=1.0, zorder=2, alpha=0.7)
    ax.text(247, ys[0]+0.55, 'Sy 245', fontsize=10, color='#C92A2A')
    ax.set_yticks(ys); ax.set_yticklabels(des, fontsize=12, color=INK)
    ax.set_xlim(0, 330); ax.grid(axis='x', color='#E6E6E6', lw=0.8, zorder=0); ax.set_axisbelow(True)
    for s_ in ('top', 'right', 'left'): ax.spines[s_].set_visible(False)
    ax.spines['bottom'].set_color('#BDBDBD'); ax.tick_params(colors=MUTED, length=0)
    fig.text(0.015, 0.95, 'Con la lectura corregida ningún diseño llega a FS 1.5 a 3g, ni el actual; P3, P4 y P2-M suben 11–14 %',
             fontsize=13.5, fontweight='bold', color=INK)
    fig.text(0.015, 0.895, 'von Mises máx. a 3g (LC5) en tensión plana, fuera de 250 mm de los apoyos · trazo negro: lectura con el esfuerzo espurio a través del espesor (método de la memoria)',
             fontsize=9.5, color=MUTED)
    plt.subplots_adjust(left=0.07, right=0.99, top=0.84, bottom=0.08)
    fig.savefig(f'{OUT}/lc5_todos_tension_plana.png'); plt.close(fig)


def field_panel(tag, field, vmax, title, sub, mode='ext', W=900, H=820):
    M, D = load(tag)
    P = D['plates']; names = [p['name'] for p in P]; cats = [p['cat'] for p in P]
    val = np.load(f'runs/{tag}_{field}.npy')
    if mode == 'ext':
        mask = np.array([cats[p] not in ('mamparo', 'techo', 'diafragma') for p in M['plate']])
        azim, elev = -50, -18
    else:
        hide = ('EXT_POST_CARA', 'EXT_POST_CHAFLAN', 'EXT_POST_EXTERIOR', 'EXT_LAT_EXTERIOR', 'EXT_LAT_FRONTAL',
                'PARED_POSTERIOR', 'PATCH_LUG_R', 'BANDA_SUP_POSTERIOR', 'PARED_EXTERIOR', 'BANDA_SUP_EXTERIOR')
        mask = np.array([not (cats[p] == 'techo' or names[p] in hide) for p in M['plate']])
        azim, elev = -50, 24
    nf = nodal_field(M['conn'], M['etype'], M['plate'], val)
    tris, own = mesh_tris(M['nodes'], M['conn'], M['etype'], mask)
    vals = []
    for k in range(len(M['conn'])):
        if not mask[k]: continue
        c = [int(x) for x in M['conn'][k]]; p = int(M['plate'][k])
        if M['etype'][k] == 'S8R':
            seq = [(c[0], c[4]), (c[4], c[1]), (c[1], c[5]), (c[5], c[2]), (c[2], c[6]), (c[6], c[3]), (c[3], c[7]), (c[7], c[0])]
        else:
            seq = [(c[0], c[3]), (c[3], c[1]), (c[1], c[4]), (c[4], c[2]), (c[2], c[5]), (c[5], c[0])]
        for a, b in seq: vals.append((nf[(a, p)] + nf[(b, p)] + val[k])/3)
    cols = turbo(np.array(vals)/vmax)
    im, _ = raster(tris, cols, azim=azim, elev=elev, W=W, H=H, frame=FRAME, shade_min=0.8)
    d = ImageDraw.Draw(im)
    d.text((14, 10), title, font=ImageFont.truetype(FONT_B, 26), fill=(20, 20, 20))
    d.text((14, 44), sub, font=ImageFont.truetype(FONT_R, 19), fill=(80, 80, 80))
    colorbar(im, W-90, 160, 420, vmax, label='MPa', fsize=19, wbar=24)
    return im


def fig_fields():
    rows = []
    for field, vmax, lab, fn in (('vm_lc5', 200, 'von Mises, LC5 (3g vertical)', 'vm_LC5_P3_P4.png'),
                                ('p1g', 80, 'Rango de esfuerzo principal por 1g', 'rango1g_P3_P4.png')):
        ims = []
        for tag, nm in (('B0', 'B0 reconstruido'), ('P3', 'P3'), ('P4', 'P4')):
            ims.append(field_panel(tag, field, vmax, f'{nm} - {lab}', f'Máx. de caras sup./inf., tensión plana. Escala fija 0-{vmax} MPa'))
        w, h = ims[0].size
        g = Image.new('RGB', (w*3, h), 'white')
        for i, im in enumerate(ims): g.paste(im, (i*w, 0))
        g.save(f'{OUT}/{fn}')
        if field == 'vm_lc5':
            ims = [field_panel(tag, field, vmax, f'{nm} - interior, LC5', 'Rompeolas y diafragma; caras nuevas y techo ocultos. Escala 0-200 MPa', mode='cut')
                   for tag, nm in (('B0', 'B0 reconstruido'), ('P3', 'P3'), ('P4', 'P4'))]
            g = Image.new('RGB', (w*3, h), 'white')
            for i, im in enumerate(ims): g.paste(im, (i*w, 0))
            g.save(f'{OUT}/vm_LC5_interior_P3_P4.png')


if __name__ == '__main__':
    what = sys.argv[1:] or ['models', 'chart', 'fields']
    if 'models' in what: fig_models()
    if 'chart' in what: fig_chart(); fig_chart_all()
    if 'fields' in what: fig_fields()
