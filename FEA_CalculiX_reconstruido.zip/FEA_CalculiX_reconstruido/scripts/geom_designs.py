"""Definición de planchas (superficie media) de cada diseño del tanque 980E-5.

Coordenadas en mm, mismo sistema que los STEP del repositorio:
  x: lateral (0 = cara exterior del lado bastidor / cara interior, + hacia afuera)
  y: longitudinal (0 = cara posterior exterior, + hacia el frente)
  z: vertical (0 = cara interior del fondo original)
Cada plancha es un polígono plano (lista de puntos 3D) con agujeros opcionales.
"""
import math, copy

T = 8.0          # espesor de plancha
H2 = T / 2

# --- planta exterior del tanque original (STEP)
X_OUT = 2292.0
Y_WIDE = 1321.0
Y_NARROW = 1040.0
CH_A = (570.0, 1321.0)   # inicio chaflán (exterior)
CH_B = (1172.0, 1040.0)  # fin chaflán (exterior)

# superficies medias
XI = H2                 # pared interior (lado bastidor)
XE = X_OUT - H2         # pared exterior
YR = H2                 # pared posterior
YW = Y_WIDE - H2        # frontal ancha
YN = Y_NARROW - H2      # frontal angosta
Z_BOT = -H2             # fondo original (z -8..0)
Z_ROOF = 2240 + H2      # techo original (2240..2248)
Z_SKIRT = -44.0         # borde inferior del faldón

def _offset_line(p, q, d, inside):
    dx, dy = q[0]-p[0], q[1]-p[1]; L = math.hypot(dx, dy)
    n = (-dy/L, dx/L)
    if (inside[0]-p[0])*n[0] + (inside[1]-p[1])*n[1] < 0: n = (-n[0], -n[1])
    return (p[0]+d*n[0], p[1]+d*n[1]), (q[0]+d*n[0], q[1]+d*n[1])

def _inter_y(line, y):
    (x1, y1), (x2, y2) = line
    t = (y - y1)/(y2 - y1); return x1 + t*(x2 - x1)

CH_MID = _offset_line(CH_A, CH_B, H2, (300, 300))
XA = _inter_y(CH_MID, YW)     # chaflán medio corta frontal ancha
XB = _inter_y(CH_MID, YN)     # chaflán medio corta frontal angosta

def chamfer_y(x):
    (x1, y1), (x2, y2) = CH_MID
    return y1 + (x - x1)*(y2 - y1)/(x2 - x1)

def front_y(x):
    if x <= XA: return YW
    if x >= XB: return YN
    return chamfer_y(x)

FOOT = [(XI, YR), (XE, YR), (XE, YN), (XB, YN), (XA, YW), (XI, YW)]   # planta (sup. media)

# rompeolas
Y_LONG = 520.0
X_T1 = 767.0
X_T2 = 1525.0
HOLE_R = 200.0

# apoyos (ver memoria §5)
LUG = dict(x0=50.0, x1=250.0, zc=1890.0, half=100.0, pin_dy=56.0 + H2)
LOW = [(100.0, 300.0), (1000.0, 1200.0)]   # rangos en y de los apoyos inferiores (cara interior)
LOW_Z = (200.0, 400.0)


def plate(name, cat, pts, wet=None, holes=(), t=T, new=False):
    """wet: vector normal que apunta hacia AFUERA del combustible (None = no mojada o mojada por ambas caras)."""
    return dict(name=name, cat=cat, pts=[tuple(map(float, p)) for p in pts], wet=wet,
                holes=list(holes), t=t, new=new)

def rect_x(x, y0, y1, z0, z1):   # plano x = cte
    return [(x, y0, z0), (x, y1, z0), (x, y1, z1), (x, y0, z1)]

def rect_y(y, x0, x1, z0, z1):   # plano y = cte
    return [(x0, y, z0), (x1, y, z0), (x1, y, z1), (x0, y, z1)]

def poly_z(z, poly2d):
    return [(x, y, z) for x, y in poly2d]

def vplane(p, q, z0, z1):        # plano vertical por la recta p-q
    return [(p[0], p[1], z0), (q[0], q[1], z0), (q[0], q[1], z1), (p[0], p[1], z1)]

def hole_x(x, y, z, r=HOLE_R): return dict(c=(x, y, z), r=r, n=(1, 0, 0))
def hole_y(x, y, z, r=HOLE_R): return dict(c=(x, y, z), r=r, n=(0, 1, 0))
def slot_y(x, y, z, w, h): return dict(rect=True, round=True, c=(x, y, z), w=w, h=h, n=(0, 1, 0))
def slot_x(x, y, z, w, h): return dict(rect=True, c=(x, y, z), w=w, h=h, n=(1, 0, 0))


def walls(zlo, zhi, prefix='PARED', cat='pared', new=False, skip=()):
    """Paredes perimetrales originales entre zlo y zhi."""
    out = []
    W = {
        'POSTERIOR': (rect_y(YR, XI, XE, zlo, zhi), (0, -1, 0)),
        'EXTERIOR': (rect_x(XE, YR, YN, zlo, zhi), (1, 0, 0)),
        'FRONTAL_ANGOSTA': (rect_y(YN, XB, XE, zlo, zhi), (0, 1, 0)),
        'CHAFLAN': (vplane((XA, YW), (XB, YN), zlo, zhi), None),
        'FRONTAL_ANCHA': (rect_y(YW, XI, XA, zlo, zhi), (0, 1, 0)),
        'INTERIOR': (rect_x(XI, YR, YW, zlo, zhi), (-1, 0, 0)),
    }
    (x1, y1), (x2, y2) = (XA, YW), (XB, YN)
    nx, ny = (y2 - y1), -(x2 - x1); L = math.hypot(nx, ny); nch = (nx/L, ny/L)
    if nch[1] < 0: nch = (-nch[0], -nch[1])
    W['CHAFLAN'] = (W['CHAFLAN'][0], (nch[0], nch[1], 0))
    for k, (pts, n) in W.items():
        if k in skip: continue
        out.append(plate(f'{prefix}_{k}', cat, pts, wet=n, new=new))
    return out


def baffles(z0, z1, holes=True, suffix='', new=False, zh=None, x_end=XE):
    zc = (0 + 2240)/2 if zh is None else zh
    out = []
    hl = [hole_y(x, Y_LONG, zc) for x in ((XI+X_T1)/2, (X_T1+X_T2)/2, (X_T2+XE)/2)] if holes else []
    out.append(plate('MAMPARO_LONG'+suffix, 'mamparo', rect_y(Y_LONG, XI, x_end, z0, z1), holes=hl, new=new))
    for nm, xx in (('T1', X_T1), ('T2', X_T2)):
        yf = front_y(xx)
        out.append(plate(f'MAMPARO_{nm}_POST'+suffix, 'mamparo', rect_x(xx, YR, Y_LONG, z0, z1),
                         holes=[hole_x(xx, (YR+Y_LONG)/2, zc)] if holes else [], new=new))
        out.append(plate(f'MAMPARO_{nm}_FRONT'+suffix, 'mamparo', rect_x(xx, Y_LONG, yf, z0, z1),
                         holes=[hole_x(xx, (Y_LONG+yf)/2, zc)] if holes else [], new=new))
    return out


def baffle_ext(z0, z1, suffix):
    """Prolongaciones de rompeolas (sin agujeros), p.ej. hacia el fondo nuevo o techo elevado."""
    return baffles(z0, z1, holes=False, suffix=suffix, new=True)


def support_patches():
    """Parches de apoyo: se incluyen como superficies propias (mismo plano que la pared)."""
    zc, h = LUG['zc'], LUG['half']
    out = [plate('PATCH_LUG_R', 'patch', rect_y(YR, LUG['x0'], LUG['x1'], zc-h, zc+h)),
           plate('PATCH_LUG_F', 'patch', rect_y(YW, LUG['x0'], LUG['x1'], zc-h, zc+h))]
    for i, (y0, y1) in enumerate(LOW, 1):
        out.append(plate(f'PATCH_LOW_{i}', 'patch', rect_x(XI, y0, y1, *LOW_Z)))
    return out


# --------------------------------------------------------------------------- diseños
def design_B0():
    P = []
    P += walls(Z_SKIRT, Z_ROOF)
    P.append(plate('FONDO', 'fondo', poly_z(Z_BOT, FOOT), wet=(0, 0, -1)))
    P.append(plate('TECHO', 'techo', poly_z(Z_ROOF, FOOT), wet=(0, 0, 1)))
    P += baffles(Z_BOT, Z_ROOF)
    return dict(name='B0', plates=P, z_roof=Z_ROOF, z_bot=Z_BOT, vent=(1146.0, 660.0, Z_ROOF),
                foot=FOOT, extra_foot=[], h_in=2240.0, d_up=0.0, d_down=0.0)


EXT_DOWN = 300.0
Z_CUT_LO = 30.0
Z_BOT_NEW = Z_BOT - EXT_DOWN          # -304
Z_SKIRT_NEW = Z_SKIRT - EXT_DOWN      # -344


def _bottom_ext(P, keep_original=False, t_new=T):
    if keep_original:
        # paredes originales hasta el faldón (-44); banda nueva -344..-44; fondo original como diafragma
        P += walls(Z_SKIRT_NEW, Z_SKIRT, prefix='BANDA_INF', cat='banda_inf', new=True)
        holes = []
        # aberturas del diafragma: una por bahía (6 bahías entre rompeolas)
        for xc in ((XI+X_T1)/2, (X_T1+X_T2)/2, (X_T2+XE)/2):
            for yc in ((YR+Y_LONG)/2, (Y_LONG+min(front_y(xc), YN))/2):
                holes.append(dict(c=(xc, yc, Z_BOT), r=HOLE_R, n=(0, 0, 1)))
        P.append(plate('DIAFRAGMA_FONDO_ORIG', 'diafragma', poly_z(Z_BOT, FOOT), holes=holes))
        P.append(plate('FONDO_NUEVO', 'fondo', poly_z(Z_BOT_NEW, FOOT), wet=(0, 0, -1), t=t_new, new=True))
        P += baffle_ext(Z_BOT_NEW, Z_BOT, '_EXT_INF')
    else:
        P += walls(Z_SKIRT_NEW, Z_CUT_LO, prefix='BANDA_INF', cat='banda_inf', new=True)
        P.append(plate('FONDO_NUEVO', 'fondo', poly_z(Z_BOT_NEW, FOOT), wet=(0, 0, -1), t=t_new, new=True))
        P += baffle_ext(Z_BOT_NEW, Z_BOT, '_EXT_INF')
    return P


def _rear_box(P):
    """Caja posterior de P1: 1,400 x 300 x 1,000 mm, chaflán 45° en la base, mamparo central Ø150."""
    xb0, xb1 = 350 + H2, 1750 - H2
    yb = -300 + H2
    ztop = Z_ROOF
    zf = 1548.0           # arranque del chaflán en la cara (y=-296)
    zw = 1248.0           # encuentro chaflán-pared posterior (y = YR)
    P.append(plate('CAJA_CARA', 'caja', rect_y(yb, xb0, xb1, zf, ztop), wet=(0, -1, 0), new=True))
    P.append(plate('CAJA_CHAFLAN', 'caja', [(xb0, yb, zf), (xb1, yb, zf), (xb1, YR, zw), (xb0, YR, zw)],
                   wet=(0, -0.7071, -0.7071), new=True))
    sec = [(xb0, YR, zw), (xb0, yb, zf), (xb0, yb, ztop), (xb0, YR, ztop)]
    P.append(plate('CAJA_EXTREMO_1', 'caja', sec, wet=(-1, 0, 0), new=True))
    P.append(plate('CAJA_EXTREMO_2', 'caja', [(xb1, p[1], p[2]) for p in sec], wet=(1, 0, 0), new=True))
    P.append(plate('CAJA_TAPA', 'caja', rect_z(ztop, xb0, xb1, yb, YR), wet=(0, 0, 1), new=True))
    xm = 1050.0
    P.append(plate('CAJA_MAMPARO', 'mamparo', [(xm, YR, zw), (xm, yb, zf), (xm, yb, ztop), (xm, YR, ztop)],
                   holes=[dict(c=(xm, (yb+YR)/2, 1900.0), r=75.0, n=(1, 0, 0))], new=True))


def rect_z(z, x0, x1, y0, y1):
    return [(x0, y0, z), (x1, y0, z), (x1, y1, z), (x0, y1, z)]


def _rear_wall_with_openings(zlo, zhi, openings):
    pts = rect_y(YR, XI, XE, zlo, zhi)
    return plate('PARED_POSTERIOR', 'pared', pts, wet=None, holes=openings)   # mojada por ambas caras en la zona de la caja


def design_P1(modified=False):
    P = []
    zlo = Z_SKIRT if modified else Z_CUT_LO
    P += walls(zlo, Z_ROOF, skip=('POSTERIOR',))
    # pared posterior: 4 ranuras 60x600 + 2 venteos Ø50 dentro de la caja
    ops = [slot_y(x, YR, 1650.0, 60, 600) for x in (560, 960, 1290, 1640)]   # fuera de las líneas de rompeolas (767, 1050, 1525)
    ops += [hole_y(x, YR, 2190.0, 25.0) for x in (700, 1400)]
    rw = _rear_wall_with_openings(zlo, Z_ROOF, ops)
    rw['wet'] = (0, -1, 0); rw['wet_mask'] = 'outside_box'
    P.append(rw)
    P.append(plate('TECHO', 'techo', poly_z(Z_ROOF, FOOT), wet=(0, 0, 1)))
    P += baffles(Z_BOT if modified else Z_BOT, Z_ROOF)
    _bottom_ext(P, keep_original=modified, t_new=10.0 if modified else T)
    _rear_box(P)
    name = 'P1-M' if modified else 'P1'
    return dict(name=name, plates=P, z_roof=Z_ROOF, z_bot=Z_BOT_NEW, vent=(1146.0, 660.0, Z_ROOF), foot=FOOT,
                box=True, h_in=2240.0 + EXT_DOWN, d_up=0.0, d_down=EXT_DOWN)


EXT_UP_P2 = 150.0
Z_CUT_HI = 2240 - 30.0     # 2210


def _roof_raise(P, d_up, zlo_walls, skip_walls=()):
    zr = Z_ROOF + d_up
    P += walls(Z_CUT_HI, zr, prefix='BANDA_SUP', cat='banda_sup', new=True, skip=skip_walls)
    P.append(plate('TECHO_REUBICADO', 'techo', poly_z(zr, FOOT), wet=(0, 0, 1)))
    P += baffle_ext(Z_ROOF, zr, '_EXT_SUP')
    return zr


def design_P2(modified=False):
    P = []
    zlo = Z_SKIRT if modified else Z_CUT_LO
    P += walls(zlo, Z_CUT_HI)
    P += baffles(Z_BOT, Z_ROOF)
    zr = _roof_raise(P, EXT_UP_P2, zlo)
    _bottom_ext(P, keep_original=modified, t_new=10.0 if modified else T)
    name = 'P2-M' if modified else 'P2'
    return dict(name=name, plates=P, z_roof=zr, z_bot=Z_BOT_NEW, vent=(1146.0, 660.0, zr), foot=FOOT,
                h_in=2240.0 + EXT_DOWN + EXT_UP_P2, d_up=EXT_UP_P2, d_down=EXT_DOWN)


# ---- extensión posterior (envolvente OEM 220 mm) para P3 y P4
REAR_D = 220.0
YRX = -REAR_D + H2            # cara posterior nueva (-216)
RA = (586.5, 0.0)             # chaflán en planta (exterior)
RB = (1067.2, -REAR_D)
RCH_MID = _offset_line(RA, RB, H2, (1500, -100))
def _rch_x_at(y):
    (x1, y1), (x2, y2) = RCH_MID
    return x1 + (y - y1)*(x2 - x1)/(y2 - y1)
RXA = _rch_x_at(YR)     # chaflán medio en y = YR
RXB = _rch_x_at(YRX)    # chaflán medio en y = YRX


def _rear_ext(P, ztop, x_out, close_ext_wall=True):
    """Extensión posterior 220 mm; la pared posterior original queda como diafragma con aberturas."""
    P.append(plate('EXT_POST_CARA', 'ext_post', rect_y(YRX, RXB, x_out, Z_SKIRT, ztop), wet=(0, -1, 0), new=True))
    nx, ny = (YRX - YR), -(RXB - RXA); L = math.hypot(nx, ny); n = (nx/L, ny/L)
    if n[1] > 0: n = (-n[0], -n[1])
    P.append(plate('EXT_POST_CHAFLAN', 'ext_post', vplane((RXA, YR), (RXB, YRX), Z_SKIRT, ztop), wet=(n[0], n[1], 0), new=True))
    if close_ext_wall:
        P.append(plate('EXT_POST_EXTERIOR', 'ext_post', rect_x(XE, YRX, YR, Z_SKIRT, ztop), wet=(1, 0, 0), new=True))
    foot = [(RXA, YR), (RXB, YRX), (x_out, YRX), (x_out, YR)]
    P.append(plate('EXT_POST_FONDO', 'fondo', poly_z(Z_BOT, foot), wet=(0, 0, -1), new=True))
    P.append(plate('EXT_POST_TECHO', 'techo', poly_z(ztop, foot), wet=(0, 0, 1), new=True))
    P.append(plate('MAMPARO_T2_EXT_POST', 'mamparo', rect_x(X_T2, YRX, YR, Z_BOT, ztop), new=True))
    return foot


def _rear_diaphragm(z0, z1, x_lim):
    """Pared posterior original: tramo x<RXA sigue siendo pared exterior; tramo dentro de la extensión
    queda mojado por ambas caras (diafragma) con 2 agujeros Ø400 por panel + 2 venteos Ø50."""
    P = []
    P.append(plate('PARED_POSTERIOR', 'pared', rect_y(YR, XI, RXA, z0, z1), wet=(0, -1, 0)))
    holes = []
    for xa, xb in ((X_T1, X_T2), (X_T2, x_lim)):
        xc = (xa + xb)/2
        holes += [hole_y(xc, YR, 600.0), hole_y(xc, YR, 1700.0)]
    holes += [hole_y(x, YR, min(z1, Z_ROOF) - 60.0, 25.0) for x in (1146.0, 1906.0)]
    P.append(plate('DIAFRAGMA_POSTERIOR', 'diafragma', rect_y(YR, RXA, XE, z0, z1), holes=holes))
    return P


EXT_UP_P3 = 160.0


def design_P3():
    P = []
    zr = Z_ROOF + EXT_UP_P3
    P += walls(Z_SKIRT, Z_CUT_HI, skip=('POSTERIOR',))
    P += _rear_diaphragm(Z_SKIRT, Z_CUT_HI, XE)
    P.append(plate('FONDO', 'fondo', poly_z(Z_BOT, FOOT), wet=(0, 0, -1)))
    P += baffles(Z_BOT, Z_ROOF)
    # elevación del techo +160 mm (banda 198 mm); la banda posterior se divide igual que la pared
    bs = walls(Z_CUT_HI, zr, prefix='BANDA_SUP', cat='banda_sup', new=True, skip=('POSTERIOR',))
    P += bs
    P.append(plate('BANDA_SUP_POSTERIOR', 'banda_sup', rect_y(YR, XI, RXA, Z_CUT_HI, zr), wet=(0, -1, 0), new=True))
    P.append(plate('BANDA_SUP_DIAFRAGMA', 'diafragma', rect_y(YR, RXA, XE, Z_CUT_HI, zr), new=True))
    P.append(plate('TECHO_REUBICADO', 'techo', poly_z(zr, FOOT), wet=(0, 0, 1)))
    P += baffle_ext(Z_ROOF, zr, '_EXT_SUP')
    foot = _rear_ext(P, zr, XE + 0.0, close_ext_wall=True)
    return dict(name='P3', plates=P, z_roof=zr, z_bot=Z_BOT, vent=(1146.0, 660.0, zr), foot=FOOT, extra_foot=[foot],
                h_in=2240.0 + EXT_UP_P3, d_up=EXT_UP_P3, d_down=0.0)


LAT_W = 180.0
XEX = XE + LAT_W            # pared exterior nueva (2468)


def design_P4():
    P = []
    P += walls(Z_SKIRT, Z_ROOF, skip=('POSTERIOR', 'EXTERIOR'))
    P += _rear_diaphragm(Z_SKIRT, Z_ROOF, XE)
    # pared exterior original -> diafragma con 2 agujeros Ø400 por panel + venteos
    holes = []
    for ya, yb in ((YR, Y_LONG), (Y_LONG, YN)):
        yc = (ya + yb)/2
        holes += [hole_x(XE, yc, 600.0), hole_x(XE, yc, 1700.0)]
    holes += [hole_x(XE, y, Z_ROOF - 60.0, 25.0) for y in (260.0, 780.0)]
    P.append(plate('DIAFRAGMA_EXTERIOR', 'diafragma', rect_x(XE, YR, YN, Z_SKIRT, Z_ROOF), holes=holes))
    P.append(plate('FONDO', 'fondo', poly_z(Z_BOT, FOOT), wet=(0, 0, -1)))
    P.append(plate('TECHO', 'techo', poly_z(Z_ROOF, FOOT), wet=(0, 0, 1)))
    P += baffles(Z_BOT, Z_ROOF)
    # extensión posterior hasta la nueva pared exterior
    P.append(plate('EXT_POST_CARA', 'ext_post', rect_y(YRX, RXB, XEX, Z_SKIRT, Z_ROOF), wet=(0, -1, 0), new=True))
    nx, ny = (YRX - YR), -(RXB - RXA); L = math.hypot(nx, ny); n = (nx/L, ny/L)
    if n[1] > 0: n = (-n[0], -n[1])
    P.append(plate('EXT_POST_CHAFLAN', 'ext_post', vplane((RXA, YR), (RXB, YRX), Z_SKIRT, Z_ROOF), wet=(n[0], n[1], 0), new=True))
    P.append(plate('EXT_LAT_EXTERIOR', 'ext_lat', rect_x(XEX, YRX, YN, Z_SKIRT, Z_ROOF), wet=(1, 0, 0), new=True))
    P.append(plate('EXT_LAT_FRONTAL', 'ext_lat', rect_y(YN, XE, XEX, Z_SKIRT, Z_ROOF), wet=(0, 1, 0), new=True))
    foot = [(RXA, YR), (RXB, YRX), (XEX, YRX), (XEX, YN), (XE, YN), (XE, YR)]
    P.append(plate('EXT_FONDO', 'fondo', poly_z(Z_BOT, foot), wet=(0, 0, -1), new=True))
    P.append(plate('EXT_TECHO', 'techo', poly_z(Z_ROOF, foot), wet=(0, 0, 1), new=True))
    P.append(plate('MAMPARO_T2_EXT_POST', 'mamparo', rect_x(X_T2, YRX, YR, Z_BOT, Z_ROOF), new=True))
    P.append(plate('MAMPARO_LONG_EXT_LAT', 'mamparo', rect_y(Y_LONG, XE, XEX, Z_BOT, Z_ROOF), new=True))
    # prolongación del plano de la pared exterior original en la zona posterior (rompeolas de esquina)
    P.append(plate('MAMPARO_EXT_ESQUINA', 'mamparo', rect_x(XE, YRX, YR, Z_BOT, Z_ROOF), new=True))
    return dict(name='P4', plates=P, z_roof=Z_ROOF, z_bot=Z_BOT, vent=(1146.0, 660.0, Z_ROOF), foot=FOOT, extra_foot=[foot],
                h_in=2240.0, d_up=0.0, d_down=0.0)


DESIGNS = {
    'B0': design_B0,
    'P1': lambda: design_P1(False),
    'P2': lambda: design_P2(False),
    'P1-M': lambda: design_P1(True),
    'P2-M': lambda: design_P2(True),
    'P3': design_P3,
    'P4': design_P4,
}


def _contains(P, pt, tol=1e-3):
    """pt en el plano de la plancha P y dentro de su contorno (planchas verticales)."""
    import numpy as np
    pts = np.array(P['pts']); p0 = pts[0]
    n = np.cross(pts[1]-p0, pts[2]-p0); n /= np.linalg.norm(n)
    if abs(np.dot(np.array(pt)-p0, n)) > tol: return False
    if abs(n[2]) > 0.5: return False
    u = np.cross([0, 0, 1.0], n); u /= np.linalg.norm(u)
    us = (pts-p0) @ u; zs = pts[:, 2]
    q = (np.array(pt)-p0) @ u
    return us.min()-tol <= q <= us.max()+tol and zs.min()-tol <= pt[2] <= zs.max()+tol


def get(name):
    import numpy as np
    d = DESIGNS[name]()
    patches = support_patches()
    # el contorno de cada parche se recorta en la pared que lo contiene (malla conforme garantizada)
    for pa in patches:
        pts = pa['pts']
        c = tuple(sum(p[i] for p in pts)/4 for i in range(3))
        for P in d['plates']:
            if P['cat'] == 'patch' or not _contains(P, c): continue
            xs = [p[0] for p in pts]; ys = [p[1] for p in pts]; zs = [p[2] for p in pts]
            w = max(max(xs)-min(xs), max(ys)-min(ys)); h = max(zs)-min(zs)
            p0 = np.array(P['pts'][0]); n = np.cross(np.array(P['pts'][1])-p0, np.array(P['pts'][2])-p0); n /= np.linalg.norm(n)
            P['holes'].append(dict(rect=True, c=c, w=w, h=h, n=tuple(float(v) for v in n)))
            break
        else:
            raise RuntimeError('parche sin pared: ' + pa['name'])
    d['plates'] += patches
    return d
