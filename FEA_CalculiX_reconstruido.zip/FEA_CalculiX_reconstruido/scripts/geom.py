import math
from OCP.gp import gp_Pnt, gp_Vec, gp_Trsf
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakePolygon, BRepBuilderAPI_MakeFace, BRepBuilderAPI_Transform
from OCP.BRepPrimAPI import BRepPrimAPI_MakePrism, BRepPrimAPI_MakeBox
from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut, BRepAlgoAPI_Common
def prism(poly, z0, z1):
    mp=BRepBuilderAPI_MakePolygon()
    for x,y in poly: mp.Add(gp_Pnt(x,y,z0))
    mp.Close()
    f=BRepBuilderAPI_MakeFace(mp.Wire()).Face()
    return BRepPrimAPI_MakePrism(f, gp_Vec(0,0,z1-z0)).Shape()
def box(x0,y0,z0,x1,y1,z1):
    return BRepPrimAPI_MakeBox(gp_Pnt(x0,y0,z0),gp_Pnt(x1,y1,z1)).Shape()
def cut(a,b): return BRepAlgoAPI_Cut(a,b).Shape()
def common(a,b): return BRepAlgoAPI_Common(a,b).Shape()
def move(s,dx=0,dy=0,dz=0):
    t=gp_Trsf(); t.SetTranslation(gp_Vec(dx,dy,dz)); return BRepBuilderAPI_Transform(s,t,True).Shape()
def area(poly):
    a=0
    for i in range(len(poly)):
        x0,y0=poly[i]; x1,y1=poly[(i+1)%len(poly)]; a+=x0*y1-x1*y0
    return abs(a)/2
def offset_line(p,q,d,inside):
    # shift line pq by d toward point 'inside'
    dx,dy=q[0]-p[0],q[1]-p[1]; L=math.hypot(dx,dy); n=(-dy/L,dx/L)
    if (inside[0]-p[0])*n[0]+(inside[1]-p[1])*n[1]<0: n=(-n[0],-n[1])
    return (p[0]+d*n[0],p[1]+d*n[1]),(q[0]+d*n[0],q[1]+d*n[1])
def inter(l1,l2):
    (x1,y1),(x2,y2)=l1; (x3,y3),(x4,y4)=l2
    den=(x1-x2)*(y3-y4)-(y1-y2)*(x3-x4)
    px=((x1*y2-y1*x2)*(x3-x4)-(x1-x2)*(x3*y4-y3*x4))/den
    py=((x1*y2-y1*x2)*(y3-y4)-(y1-y2)*(x3*y4-y3*x4))/den
    return (px,py)
def inner_poly(poly,t,inside,skip=()):
    # offset each edge inward by t (edges in skip are offset 0)
    n=len(poly); lines=[]
    for i in range(n):
        p,q=poly[i],poly[(i+1)%n]
        lines.append(offset_line(p,q,0 if i in skip else t,inside))
    return [inter(lines[i-1],lines[i]) for i in range(n)]
