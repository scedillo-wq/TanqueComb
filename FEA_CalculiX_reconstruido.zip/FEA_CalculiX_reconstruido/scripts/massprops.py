import numpy as np, json, sys
from capacity import capacities
RHO=7850e-9 # kg/mm3
out={}
for name in ['B0','P1','P2','P1-M','P2-M','P3','P4']:
    tag=name.replace('-','')
    M=np.load(f'runs/{tag}_mesh.npz'); D=json.load(open(f'runs/{tag}_design.json'))
    t=np.array([D['plates'][p]['t'] for p in M['plate']])
    m=M['area']*t*RHO; ms=m.sum(); cs=(m[:,None]*M['cen']).sum(0)/ms
    c=capacities(name); mf=c['fuel_jet_kg']; cf=np.array(c['fuel_cg'])
    mt=ms+mf; cg=(ms*cs+mf*cf)/mt
    out[name]=dict(steel=ms, steel_cg=cs.tolist(), fuel=mf, fuel_cg=cf.tolist(), total=mt, cg=cg.tolist(), cap=c)
    print(f"{name:5s} acero {ms:7.0f} kg  CGacero {cs.round(0)}  comb {mf:6.0f}  total {mt:6.0f}  CG {cg.round(0)}  cap {c['gross']:.0f}/{c['jet']:.0f}/{c['useful']:.0f}")
json.dump(out,open('runs/massprops.json','w'),indent=1,default=float)
