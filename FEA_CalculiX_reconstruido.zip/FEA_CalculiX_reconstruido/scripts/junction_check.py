"""Verifica que toda arista de plancha apoyada sobre otra plancha comparta nodos en la malla."""
import numpy as np, json, sys
import geom_designs as G
from scipy.spatial import cKDTree
def plane(P):
    pts=np.array(P['pts']); p0=pts[0]; n=np.cross(pts[1]-p0,pts[2]-p0); n/=np.linalg.norm(n); return p0,n
def inside(P,x,tol=0.5):
    pts=np.array(P['pts']); p0,n=plane(P)
    if abs((x-p0)@n)>tol: return False
    # proyección 2D
    a=np.argmax(np.abs(n)); idx=[i for i in range(3) if i!=a]
    poly=pts[:,idx]; q=x[idx]
    # punto en polígono (incluye borde)
    c=False; m=len(poly)
    for i in range(m):
        x1,y1=poly[i]; x2,y2=poly[(i+1)%m]
        # en borde
        d=np.array([x2-x1,y2-y1]); L=np.hypot(*d)
        if L>0:
            t=np.clip(((q[0]-x1)*d[0]+(q[1]-y1)*d[1])/L**2,0,1)
            if np.hypot(q[0]-(x1+t*d[0]),q[1]-(y1+t*d[1]))<tol: return True
        if ((y1>q[1])!=(y2>q[1])) and (q[0] < (x2-x1)*(q[1]-y1)/(y2-y1)+x1): c=not c
    if not c: return False
    for H in P['holes']:
        cc=np.array(H['c'])
        if H.get('rect'):
            hn=np.array(H['n']); v=np.array([0,0,1.0]); u=np.cross(v,hn); u/=np.linalg.norm(u)
            if abs((x-cc)@u)<H['w']/2-tol and abs((x-cc)@v)<H['h']/2-tol: return False
        else:
            if np.linalg.norm(x-cc)<H['r']-tol: return False
    return True
for name in sys.argv[1:]:
    D=G.get(name); tag=name.replace('-','')
    M=np.load(f'runs/{tag}_mesh.npz'); nodes=M['nodes']; conn=M['conn']; plate=M['plate']
    plates=D['plates']
    node_pl={}
    for k in range(len(conn)):
        for n in conn[k]:
            if n>0: node_pl.setdefault(int(n),set()).add(int(plate[k]))
    tree=cKDTree(nodes)
    bad=[]; npairs=0
    for i,A in enumerate(plates):
        pts=np.array(A['pts'])
        for e in range(len(pts)):
            a,b=pts[e],pts[(e+1)%len(pts)]; L=np.linalg.norm(b-a); ns=max(int(L/50),2)
            samples=[a+(b-a)*t for t in np.linspace(0.02,0.98,ns)]
            for j,B in enumerate(plates):
                if j==i: continue
                pa=[s for s in samples if inside(B,s)]
                if len(pa)<2: continue
                npairs+=1
                ok=0
                for s in pa:
                    d,k=tree.query(s,k=4)
                    good=any(dd<30 and {i,j}<=node_pl.get(int(kk)+1,set()) for dd,kk in zip(d,k))
                    ok+=good
                frac=ok/len(pa)
                if frac<0.9: bad.append((A['name'],B['name'],len(pa),round(frac,2)))
    print(name,'pares',npairs,'MAL' if bad else 'OK', bad[:20])
