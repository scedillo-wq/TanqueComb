"""Malla (gmsh), modelo CalculiX (S8R) y post-proceso para un diseño del tanque.
Uso: python3 fea_run.py <DISEÑO> <dir_salida> [--mesh 50]
"""
import sys, os, json, math, subprocess, time
import numpy as np
import gmsh
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import geom_designs as G

RHO_S = 7.85e-9      # t/mm3
RHO_F = 8.5e-10      # t/mm3 (diésel 850 kg/m3)
GACC = 9810.0        # mm/s2
E, NU = 205000.0, 0.3
JET_OFFSET = 118.0
NMODES = int(os.environ.get('NMODES', '8'))   # 2240 - 2122 (estudio Komatsu): techo interior - jet sensor


def build_mesh(design, h=50.0, verbose=False):
    plates = design['plates']
    gmsh.initialize()
    gmsh.option.setNumber('General.Terminal', 1 if verbose else 0)
    gmsh.model.add(design['name'])
    occ = gmsh.model.occ
    tags = []
    for P in plates:
        pts = P['pts']
        pt_tags = [occ.addPoint(*p) for p in pts]
        ln = [occ.addLine(pt_tags[i], pt_tags[(i+1) % len(pt_tags)]) for i in range(len(pt_tags))]
        s = occ.addPlaneSurface([occ.addCurveLoop(ln)])
        tools = []
        for H in P['holes']:
            c = H['c']
            if H.get('rect'):
                hn = np.array(H['n'], float)
                v = np.array([0, 0, 1.0]); u = np.cross(v, hn); u /= np.linalg.norm(u)
                w2, h2 = H['w']/2, H['h']/2
                cc = np.array(c, float)
                qd = [cc - u*w2 - v*h2, cc + u*w2 - v*h2, cc + u*w2 + v*h2, cc - u*w2 + v*h2]
                if H.get('round'):
                    # ranura con extremos semicirculares (radio = w/2)
                    h2r = h2 - w2
                    qd = [cc - u*w2 - v*h2r, cc + u*w2 - v*h2r, cc + u*w2 + v*h2r, cc - u*w2 + v*h2r]
                qt = [occ.addPoint(*x) for x in qd]
                ql = [occ.addLine(qt[i], qt[(i+1) % 4]) for i in range(4)]
                rs = occ.addPlaneSurface([occ.addCurveLoop(ql)])
                if H.get('round'):
                    hn_l = list(hn)
                    d1 = occ.addPlaneSurface([occ.addCurveLoop([occ.addCircle(*(cc + v*h2r), w2, zAxis=hn_l, xAxis=[0, 0, 1])])])
                    d2 = occ.addPlaneSurface([occ.addCurveLoop([occ.addCircle(*(cc - v*h2r), w2, zAxis=hn_l, xAxis=[0, 0, 1])])])
                    fu, _ = occ.fuse([(2, rs)], [(2, d1), (2, d2)])
                    tools += [t for d, t in fu if d == 2]
                else:
                    tools.append(rs)
            else:
                hn = H['n']
                xax = [0, 0, 1] if abs(hn[2]) < 0.9 else [1, 0, 0]
                circ = occ.addCircle(c[0], c[1], c[2], H['r'], zAxis=list(hn), xAxis=xax)
                tools.append(occ.addPlaneSurface([occ.addCurveLoop([circ])]))
        if tools:
            res, _ = occ.cut([(2, s)], [(2, t) for t in tools])
            ss = [t for d, t in res if d == 2]
            if len(ss) != 1: raise RuntimeError(f"corte de agujeros en {P['name']}: {res}")
            s = ss[0]
        tags.append(s)
    occ.synchronize()
    out, omap = occ.fragment([(2, t) for t in tags], [])
    occ.synchronize()
    # propiedad de cada superficie resultante: los parches tienen prioridad
    owner = {}
    order = sorted(range(len(plates)), key=lambda i: 0 if plates[i]['cat'] == 'patch' else 1)
    for i in order:
        for (d, t) in omap[i]:
            if d == 2 and t not in owner:
                owner[t] = i
    for i, P in enumerate(plates):
        st = [t for t, o in owner.items() if o == i]
        if st:
            gmsh.model.addPhysicalGroup(2, st, tag=i+1, name=P['name'])
    gmsh.option.setNumber('Mesh.MeshSizeMax', h)
    gmsh.option.setNumber('Mesh.MeshSizeMin', h/4)
    gmsh.option.setNumber('Mesh.MeshSizeFromCurvature', 12)
    gmsh.option.setNumber('Mesh.Algorithm', 8)
    gmsh.option.setNumber('Mesh.RecombineAll', 1)
    gmsh.option.setNumber('Mesh.RecombinationAlgorithm', 1)
    gmsh.option.setNumber('Mesh.SecondOrderIncomplete', 1)
    gmsh.option.setNumber('Mesh.ElementOrder', 2)
    gmsh.model.mesh.generate(2)
    gmsh.model.mesh.setOrder(2)
    ntags, coords, _ = gmsh.model.mesh.getNodes()
    X = coords.reshape(-1, 3)
    nid = {int(t): k for k, t in enumerate(ntags)}
    elems = []   # (plate_index, type, [node tags])
    for t, i in owner.items():
        types, etags, enodes = gmsh.model.mesh.getElements(2, t)
        for ty, et, en in zip(types, etags, enodes):
            nn = {16: 8, 9: 6, 10: 9, 3: 4, 2: 3}[ty]
            en = en.reshape(-1, nn)
            for row in en:
                if ty == 10: row = row[:8]
                if ty in (3, 2): raise RuntimeError('elementos lineales inesperados')
                elems.append((i, 'S8R' if ty in (16, 10) else 'S6', [int(x) for x in row]))
    gmsh.finalize()
    # renumerar nodos usados
    used = sorted({n for _, _, ns in elems for n in ns})
    new = {n: k+1 for k, n in enumerate(used)}
    nodes = np.array([X[nid[n]] for n in used])
    elems = [(i, ty, [new[n] for n in ns]) for i, ty, ns in elems]
    return nodes, elems


def element_geometry(nodes, elems):
    cen = np.zeros((len(elems), 3)); nrm = np.zeros((len(elems), 3)); area = np.zeros(len(elems))
    for k, (_, ty, ns) in enumerate(elems):
        c = 4 if ty == 'S8R' else 3
        P = nodes[np.array(ns[:c]) - 1]
        cen[k] = P.mean(0)
        if c == 4:
            v = np.cross(P[2]-P[0], P[3]-P[1]); a = np.linalg.norm(v)/2
        else:
            v = np.cross(P[1]-P[0], P[2]-P[0]); a = np.linalg.norm(v)/2
        nrm[k] = v/np.linalg.norm(v); area[k] = a
    return cen, nrm, area


def in_box_mask(design, c):
    # región de la pared posterior cubierta por la caja de P1 (ambas caras mojadas)
    return (c[0] > 354) and (c[0] < 1746) and (c[2] > 1248)


def wet_info(design, plates, elems, cen, nrm):
    """Devuelve signo de presión por elemento (0 = sin presión)."""
    zb, zr = design['z_bot'], design['z_roof']
    sign = np.zeros(len(elems))
    for k, (i, ty, ns) in enumerate(elems):
        P = plates[i]
        if P['wet'] is None or P['cat'] == 'patch':
            # parches: heredan la mojadura de la pared que los contiene
            if P['cat'] == 'patch':
                nm = P['name']
                wn = {'PATCH_LUG_R': (0, -1, 0), 'PATCH_LUG_F': (0, 1, 0)}.get(nm, (-1, 0, 0))
            else:
                continue
        else:
            wn = P['wet']
        if P.get('wet_mask') == 'outside_box' and in_box_mask(design, cen[k]):
            continue
        z = cen[k][2]
        if z < zb - 1 or z > zr + 1:
            continue
        s = np.sign(np.dot(nrm[k], wn))
        sign[k] = s if s != 0 else 1
    return sign


def write_inp(path, design, nodes, elems, sign, cen, modal=False, madd=None):
    plates = design['plates']
    vent = np.array(design['vent'])
    with open(path, 'w') as f:
        f.write('*HEADING\nTanque 980E-5 %s\n' % design['name'])
        f.write('*NODE,NSET=NALL\n')
        for k, x in enumerate(nodes, 1):
            f.write(f'{k},{x[0]:.4f},{x[1]:.4f},{x[2]:.4f}\n')
        nref = len(nodes)
        refs = {'R': (G.LUG['x0']+G.LUG['x1'])/2, }
        zc = G.LUG['zc']
        ref_pts = {'LUGR': (150.0, G.YR - G.LUG['pin_dy'], zc), 'LUGF': (150.0, G.YW + G.LUG['pin_dy'], zc)}
        ref_ids = {}; gnd_ids = {}
        for nm, p in ref_pts.items():
            nref += 1; ref_ids[nm] = (nref, nref+1)
            f.write(f'{nref},{p[0]},{p[1]},{p[2]}\n{nref+1},{p[0]},{p[1]},{p[2]}\n')
            nref += 2; gnd_ids[nm] = nref
            f.write(f'{nref},{p[0]},{p[1]},{p[2]}\n')
        for ty in ('S8R', 'S6'):
            ids = [k for k, e in enumerate(elems, 1) if e[1] == ty]
            if not ids: continue
            f.write(f'*ELEMENT,TYPE={ty},ELSET=EALL\n')
            for k in ids:
                f.write(f'{k},' + ','.join(map(str, elems[k-1][2])) + '\n')
        # resortes 1e9 N/mm entre nodo de referencia y tierra (reacciones legibles)
        eid = len(elems)
        for nm in ('LUGR', 'LUGF'):
            for dof in (1, 2, 3):
                eid += 1
                f.write(f'*ELEMENT,TYPE=SPRING2,ELSET=SPR{nm}{dof}\n{eid},{ref_ids[nm][0]},{gnd_ids[nm]}\n')
                f.write(f'*SPRING,ELSET=SPR{nm}{dof}\n{dof},{dof}\n1.e9\n')
        # conjuntos por plancha
        by_plate = {}
        for k, e in enumerate(elems, 1): by_plate.setdefault(e[0], []).append(k)
        for i, ks in by_plate.items():
            f.write(f'*ELSET,ELSET=PL{i}\n')
            for j in range(0, len(ks), 16): f.write(','.join(map(str, ks[j:j+16])) + '\n')
        # secciones por espesor (y masa añadida en modal)
        groups = {}
        for k, e in enumerate(elems, 1):
            t = plates[e[0]]['t']
            ma = 0.0 if madd is None else madd[k-1]
            key = (t, round(ma, 12))
            groups.setdefault(key, []).append(k)
        for gi, ((t, ma), ks) in enumerate(groups.items()):
            f.write(f'*ELSET,ELSET=SEC{gi}\n')
            for j in range(0, len(ks), 16): f.write(','.join(map(str, ks[j:j+16])) + '\n')
            rho = RHO_S + (ma / t if modal else 0.0)
            f.write(f'*MATERIAL,NAME=M{gi}\n*ELASTIC\n{E},{NU}\n*DENSITY\n{rho:.6e}\n')
            f.write(f'*SHELL SECTION,ELSET=SEC{gi},MATERIAL=M{gi}\n{t}\n')
        # apoyos
        pidx = {P['name']: i for i, P in enumerate(plates)}
        def nset_of(name):
            i = pidx[name]
            return sorted({n for e in elems if e[0] == i for n in e[2]})
        for nm, pname in (('LUGR', 'PATCH_LUG_R'), ('LUGF', 'PATCH_LUG_F')):
            ns = nset_of(pname)
            f.write(f'*NSET,NSET=N{nm}\n')
            for j in range(0, len(ns), 16): f.write(','.join(map(str, ns[j:j+16])) + '\n')
            r, rr = ref_ids[nm]
            f.write(f'*NSET,NSET=R{nm}\n{gnd_ids[nm]}\n')
            f.write(f'*RIGID BODY,NSET=N{nm},REF NODE={r},ROT NODE={rr}\n')
        for j in (1, 2):
            ns = nset_of(f'PATCH_LOW_{j}')
            f.write(f'*NSET,NSET=NLOW{j}\n')
            for q in range(0, len(ns), 16): f.write(','.join(map(str, ns[q:q+16])) + '\n')
        f.write('*BOUNDARY\n')
        for nm in ('LUGR', 'LUGF'):
            f.write(f'{gnd_ids[nm]},1,3,0.\n')
        f.write('NLOW1,1,1,0.\nNLOW2,1,1,0.\n')
        if modal:
            f.write('*STEP\n*FREQUENCY\n' + str(NMODES) + '\n*NODE FILE\nU\n*EL FILE\nS\n*END STEP\n')
            return
        # 3 pasos unitarios: Z (1g abajo), Y (+1g inercial), X (+1g inercial)
        for lab, d in (('Z', (0, 0, -1)), ('Y', (0, 1, 0)), ('X', (1, 0, 0))):
            f.write('*STEP\n*STATIC\n*DLOAD,OP=NEW\n')
            f.write(f'EALL,GRAV,{GACC},{d[0]},{d[1]},{d[2]}\n')
            dvec = np.array(d, float)
            for k in range(len(elems)):
                if sign[k] == 0: continue
                # p = rho * g * (dvec · (r - vent)) para la dirección de la fuerza de cuerpo
                p = RHO_F * GACC * float(np.dot(dvec, cen[k] - vent))
                if lab == 'Z': p = RHO_F * GACC * (vent[2] - cen[k][2])
                if abs(p) < 1e-12: continue
                f.write(f'{k+1},P,{sign[k]*p:.6e}\n')
            f.write('*NODE PRINT,NSET=RLUGR\nRF\n*NODE PRINT,NSET=RLUGF\nRF\n')
            f.write('*NODE PRINT,NSET=NLOW1,TOTALS=ONLY\nRF\n*NODE PRINT,NSET=NLOW2,TOTALS=ONLY\nRF\n')
            f.write('*NODE PRINT,NSET=NALL\nU\n')
            f.write('*EL PRINT,ELSET=EALL\nS\n')
            f.write('*END STEP\n')


def run_ccx(path):
    base = path[:-4]
    env = dict(os.environ, OMP_NUM_THREADS='2', CCX_NPROC_EQUATION_SOLVER='2')
    t0 = time.time()
    r = subprocess.run(['ccx', '-i', os.path.basename(base)], cwd=os.path.dirname(path), env=env,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    open(base + '.log', 'w').write(r.stdout)
    if 'Job finished' not in r.stdout:
        raise RuntimeError('ccx falló: ' + r.stdout[-2000:])
    return time.time() - t0


def parse_dat(path, ne):
    """Devuelve lista por paso (según 'time') con S (ne, nip, 6), U, RF."""
    steps = {}; mode = None; cur = None
    with open(path) as f:
        for line in f:
            s = line.strip()
            if not s:
                continue
            if ' for set ' in s and ' time ' in s:
                tm = float(s.split('time')[-1])
                cur = steps.setdefault(tm, {'S': {}, 'U': {}, 'RF': {}})
                nm = s.split(' for set ')[1].split()[0]
                if s.startswith('stresses'): mode = ('S', nm)
                elif s.startswith('displacements'): mode = ('U', nm)
                elif s.startswith('forces') or s.startswith('total force'): mode = ('RF', nm)
                else: mode = ('X', nm)
                continue
            if mode is None or mode[0] == 'X':
                continue
            parts = s.split()
            try:
                if mode[0] == 'S':
                    e, ip = int(parts[0]), int(parts[1]); v = [float(x) for x in parts[2:8]]
                    cur['S'].setdefault(e, {})[ip] = v
                elif mode[0] == 'U':
                    cur['U'][int(parts[0])] = [float(x) for x in parts[1:4]]
                elif mode[0] == 'RF':
                    if len(parts) == 3: cur['RF'][mode[1]] = [float(x) for x in parts]
                    else: cur['RF'][mode[1]] = [float(x) for x in parts[1:4]]
            except (ValueError, IndexError):
                continue
    out = []
    for tm in sorted(steps):
        st = steps[tm]
        if not st['S']:
            continue
        nip = max(len(v) for v in st['S'].values())
        S = np.zeros((ne, nip, 6)); cnt = np.zeros(ne, int)
        for e, d in st['S'].items():
            for ip, v in d.items(): S[e-1, ip-1] = v
            cnt[e-1] = len(d)
        U = np.array([st['U'][k] for k in sorted(st['U'])]) if st['U'] else None
        out.append(dict(S=S, nip=cnt, U=U, RF=st['RF']))
    return out


def surfaces(S, nip):
    """Extrapola a caras inf./sup.: devuelve (ne, 2*npl, 6) con los valores en superficie."""
    ne = S.shape[0]
    res = np.zeros((ne, 8, 6))
    m8 = nip == 8
    if m8.any():
        lo = S[m8, 0:4]; hi = S[m8, 4:8]
        mid = (lo + hi)/2; bend = (hi - lo)/2*math.sqrt(3)
        res[m8, 0:4] = mid - bend; res[m8, 4:8] = mid + bend
    m9 = nip == 9      # C3D15 (S6 expandido): 3 capas x 3 puntos
    if m9.any():
        lo = S[m9, 0:3]; hi = S[m9, 6:9]
        mid = (lo + hi)/2; bend = (hi - lo)/2/math.sqrt(0.6)
        res[m9, 0:3] = mid - bend; res[m9, 4:7] = mid + bend
        res[m9, 3] = res[m9, 0]; res[m9, 7] = res[m9, 4]
    m6 = nip == 6      # alternativa 2 capas x 3 puntos
    if m6.any():
        lo = S[m6, 0:3]; hi = S[m6, 3:6]
        mid = (lo + hi)/2; bend = (hi - lo)/2*math.sqrt(3)
        res[m6, 0:3] = mid - bend; res[m6, 4:7] = mid + bend
        res[m6, 3] = res[m6, 0]; res[m6, 7] = res[m6, 4]
    return res


def vm(s):
    sx, sy, sz, txy, txz, tyz = [s[..., i] for i in range(6)]
    return np.sqrt(0.5*((sx-sy)**2 + (sy-sz)**2 + (sz-sx)**2) + 3*(txy**2 + txz**2 + tyz**2))


def principal_absmax(s):
    sx, sy, sz, txy, txz, tyz = [s[..., i] for i in range(6)]
    M = np.stack([np.stack([sx, txy, txz], -1), np.stack([txy, sy, tyz], -1), np.stack([txz, tyz, sz], -1)], -2)
    w = np.linalg.eigvalsh(M)
    return np.max(np.abs(w), -1)


if __name__ == '__main__':
    name = sys.argv[1]; out = sys.argv[2]; h = 50.0
    if '--mesh' in sys.argv: h = float(sys.argv[sys.argv.index('--mesh')+1])
    os.makedirs(out, exist_ok=True)
    D = G.get(name)
    t0 = time.time()
    nodes, elems = build_mesh(D, h)
    cen, nrm, area = element_geometry(nodes, elems)
    sign = wet_info(D, D['plates'], elems, cen, nrm)
    tag = name.replace('-', '')
    np.savez(os.path.join(out, f'{tag}_mesh.npz'), nodes=nodes, cen=cen, nrm=nrm, area=area, sign=sign,
             plate=np.array([e[0] for e in elems]), etype=np.array([e[1] for e in elems]),
             conn=np.array([e[2] + [0]*(8-len(e[2])) for e in elems]))
    json.dump(dict(name=D['name'], plates=[{k: v for k, v in P.items() if k != 'holes'} | {'nholes': len(P['holes'])} for P in D['plates']],
                   z_roof=D['z_roof'], z_bot=D['z_bot'], vent=D['vent'], h_in=D['h_in'], d_up=D['d_up'], d_down=D['d_down']),
              open(os.path.join(out, f'{tag}_design.json'), 'w'), default=float)
    print(f'{name}: {len(elems)} elementos, {len(nodes)} nodos, malla {time.time()-t0:.1f}s', flush=True)
    write_inp(os.path.join(out, f'{tag}_static.inp'), D, nodes, elems, sign, cen)
    if '--meshonly' in sys.argv: sys.exit(0)
    dt = run_ccx(os.path.join(out, f'{tag}_static.inp'))
    print(f'{name}: ccx estático {dt:.0f}s', flush=True)
