"""Exporta los resultados del modelo reconstruido a Excel."""
import json, sys
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

R = json.load(open('runs/results.json'))
DES = list(R.keys())
wb = Workbook()
hdr_fill = PatternFill('solid', fgColor='F2F2F2'); bold = Font(bold=True)

def sheet(title, header, rows, note=None):
    ws = wb.create_sheet(title)
    r0 = 1
    if note:
        ws.cell(1, 1, note).font = Font(italic=True, color='5F666D'); r0 = 3
    for j, h in enumerate(header, 1):
        c = ws.cell(r0, j, h); c.font = bold; c.fill = hdr_fill; c.alignment = Alignment(wrap_text=True, vertical='center')
    for i, row in enumerate(rows, r0+1):
        for j, v in enumerate(row, 1):
            c = ws.cell(i, j, v)
            if isinstance(v, float): c.number_format = '0.0'
    for j in range(1, len(header)+1):
        ws.column_dimensions[get_column_letter(j)].width = 34 if j == 1 else 13
    ws.freeze_panes = ws.cell(r0+1, 2)
    return ws

NOTE = 'Modelo de cáscaras CalculiX 2.21 reconstruido (S8R, malla 50 mm). Mismos apoyos, cargas y criterios que la memoria. Esfuerzos en tensión plana (sección 5.2) salvo indicación. Unidades: MPa, kN, kg, mm, Hz.'
wb.remove(wb.active)
rows = []
for lc in ['LC1', 'LC2', 'LC3', 'LC4', 'LC5']:
    rows.append([f'{lc} von Mises máx. fuera de 250 mm de apoyos'] + [R[d]['lc250'][lc] for d in DES])
for lc in ['LC1', 'LC2', 'LC3', 'LC4', 'LC5']:
    rows.append([f'{lc} von Mises máx. fuera de 150 mm de apoyos'] + [R[d]['lc150'][lc] for d in DES])
for lc in ['LC1', 'LC2', 'LC3', 'LC4', 'LC5']:
    rows.append([f'{lc} lectura de la memoria (sin corregir), fuera de 250 mm'] + [R[d]['lc250_3d'][lc] for d in DES])
rows.append(['FS a 3g (Sy 245 / LC5 fuera de 250 mm)'] + [245/R[d]['lc250']['LC5'] for d in DES])
rows.append(['LC5 entre 150 y 200 mm de los apoyos'] + [R[d]['support_150_200'] for d in DES])
rows.append(['Desplazamiento máx. a 1g (mm)'] + [R[d]['umax_1g'] for d in DES])
sheet('Resistencia', ['Resultado'] + DES, rows, NOTE)
cats = sorted({c for d in DES for c in R[d]['comp_lc5']})
sheet('Componentes LC5', ['Componente (3g, fuera de 150 mm)'] + DES, [[c] + [R[d]['comp_lc5'].get(c) for d in DES] for c in cats], NOTE)
rows_j = sorted({k for d in DES for k in R[d]['junctions']})
rj = [[k] + [R[d]['junctions'].get(k) for d in DES] for k in rows_j]
rj.append(['Unión crítica (rango por 1g)'] + [R[d]['j_crit'] for d in DES])
rj.append(['Aceleración admisible, vida ilimitada (g)'] + [R[d]['a_adm_g'] for d in DES])
rj.append(['Vida relativa vs B0 reconstruido'] + [(R['B0']['j_crit']/R[d]['j_crit'])**3 for d in DES])
sheet('Soldaduras 1g', ['Unión (rango de esfuerzo principal por 1g, MPa)'] + DES, rj, NOTE)
rr = [['Oreja posterior, 3g (kN)'] + [R[d]['R3g_lugR'] for d in DES],
      ['Oreja frontal, 3g (kN)'] + [R[d]['R3g_lugF'] for d in DES],
      ['Apoyos inferiores, suma eje X, 3g (kN)'] + [R[d]['R3g_low'] for d in DES],
      ['Mínima compresión apoyo inferior, todos los casos (kN)'] + [R[d]['low_min_kN'] for d in DES],
      ['Suma de reacciones verticales a 1g (kN)'] + [R[d]['Rz1g_sum'] for d in DES]]
sheet('Reacciones', ['Reacción'] + DES, rr, NOTE)
rm = []
for i in range(8):
    rm.append([f'Modo {i+1} (Hz)'] + [(R[d]['modal']['freq'][i] if R[d]['modal'] else None) for d in DES])
for k, lab in (('m1', 'Vaivén longitudinal Y (Hz)'), ('m2', 'Balanceo sobre las orejas (Hz)'), ('m3', 'Primer modo local de paneles (Hz)')):
    rm.append([lab] + [R[d].get('modal_class', {}).get(k) for d in DES])
sheet('Modal', ['Modo'] + DES, rm, NOTE + ' Combustible como masa adherida a paredes mojadas, lleno a jet sensor.')
mp = [['Acero del modelo (kg)'] + [R[d]['mass']['steel'] for d in DES],
      ['Combustible a jet sensor, volumen CAD (kg)'] + [R[d]['mass']['fuel'] for d in DES],
      ['Masa llena a jet sensor (kg)'] + [R[d]['mass']['total'] for d in DES],
      ['CG x (mm)'] + [R[d]['mass']['cg'][0] for d in DES], ['CG y (mm)'] + [R[d]['mass']['cg'][1] for d in DES], ['CG z (mm)'] + [R[d]['mass']['cg'][2] for d in DES],
      ['Capacidad bruta, método Komatsu (gal)'] + [R[d]['mass']['cap']['gross'] for d in DES],
      ['Capacidad a jet sensor (gal)'] + [R[d]['mass']['cap']['jet'] for d in DES],
      ['Capacidad útil (gal)'] + [R[d]['mass']['cap']['useful'] for d in DES]]
sheet('Masas y capacidades', ['Concepto'] + DES, mp, NOTE)
wb.save(sys.argv[1])
print('ok', sys.argv[1])
