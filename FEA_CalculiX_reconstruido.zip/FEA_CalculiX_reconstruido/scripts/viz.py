"""Rasterizador z-buffer simple para mallas de cáscara (sin OpenGL)."""
import math, itertools
import numpy as np
from PIL import Image, ImageDraw, ImageFont

FONT_B = '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf'
FONT_R = '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf'


def view_matrix(azim, elev):
    a = math.radians(azim); e = math.radians(elev)
    d = np.array([math.cos(e)*math.cos(a), math.cos(e)*math.sin(a), math.sin(e)])
    up = np.array([0, 0, 1.0]); right = np.cross(up, d); right /= np.linalg.norm(right); up2 = np.cross(d, right)
    return np.stack([right, up2, d])


def mesh_tris(nodes, conn, etype, mask=None):
    """Divide cada S8R/S6 en triángulos (usando nodos medios para mejor color)."""
    tris = []; owner = []
    for k in range(len(conn)):
        if mask is not None and not mask[k]: continue
        c = conn[k]
        if etype[k] == 'S8R':
            n1, n2, n3, n4, m12, m23, m34, m41 = [int(x)-1 for x in c[:8]]
            ctr = nodes[[n1, n2, n3, n4]].mean(0)
            P = nodes
            seq = [(n1, m12), (m12, n2), (n2, m23), (m23, n3), (n3, m34), (m34, n4), (n4, m41), (m41, n1)]
            for a, b in seq:
                tris.append(np.array([P[a], P[b], ctr])); owner.append(k)
        else:
            n1, n2, n3, m12, m23, m31 = [int(x)-1 for x in c[:6]]
            P = nodes; ctr = nodes[[n1, n2, n3]].mean(0)
            for a, b in [(n1, m12), (m12, n2), (n2, m23), (m23, n3), (n3, m31), (m31, n1)]:
                tris.append(np.array([P[a], P[b], ctr])); owner.append(k)
    return np.array(tris), np.array(owner)


def raster(tris, cols, azim=-50, elev=24, W=1600, H=1300, ss=2, frame=None, margin=0.06, light=True,
           edges=None, edge_col=(0.25, 0.27, 0.30), edge_w=1, shade_min=0.55):
    M = view_matrix(azim, elev)
    Lv = M.T @ np.array([-0.35, 0.55, 0.75]); Lv /= np.linalg.norm(Lv)
    if frame is None:
        allp = tris.reshape(-1, 3); lo, hi = allp.min(0), allp.max(0)
    else:
        lo, hi = np.array(frame[0], float), np.array(frame[1], float)
    FB = np.array(list(itertools.product(*zip(lo, hi)))) @ M.T
    mn, mx = FB.min(0), FB.max(0)
    w, h = W*ss, H*ss
    sc = min(w*(1-2*margin)/(mx[0]-mn[0]), h*(1-2*margin)/(mx[1]-mn[1]))
    cx, cy = (mn[0]+mx[0])/2, (mn[1]+mx[1])/2
    def toscr(p):
        p = np.atleast_2d(p) @ M.T
        return np.stack([(p[:, 0]-cx)*sc + w/2, h/2 - (p[:, 1]-cy)*sc, p[:, 2]], 1)
    img = np.ones((h, w, 3)); zb = np.full((h, w), -1e18)
    S = toscr(tris.reshape(-1, 3)).reshape(-1, 3, 3)
    nr = np.cross(tris[:, 1]-tris[:, 0], tris[:, 2]-tris[:, 0])
    nn = np.linalg.norm(nr, axis=1); nn[nn == 0] = 1; nr = nr/nn[:, None]
    shade = shade_min + (1-shade_min)*np.abs(nr @ Lv) if light else np.ones(len(tris))
    C = np.clip(cols*shade[:, None], 0, 1)
    for k in range(len(S)):
        (x0, y0, z0), (x1, y1, z1), (x2, y2, z2) = S[k]
        xmin = max(int(math.floor(min(x0, x1, x2))), 0); xmax = min(int(math.ceil(max(x0, x1, x2))), w-1)
        ymin = max(int(math.floor(min(y0, y1, y2))), 0); ymax = min(int(math.ceil(max(y0, y1, y2))), h-1)
        if xmax < xmin or ymax < ymin: continue
        den = (y1-y2)*(x0-x2) + (x2-x1)*(y0-y2)
        if abs(den) < 1e-9: continue
        X, Y = np.meshgrid(np.arange(xmin, xmax+1)+0.5, np.arange(ymin, ymax+1)+0.5)
        a = ((y1-y2)*(X-x2) + (x2-x1)*(Y-y2))/den
        b = ((y2-y0)*(X-x2) + (x0-x2)*(Y-y2))/den
        c = 1-a-b
        m = (a >= -1e-6) & (b >= -1e-6) & (c >= -1e-6)
        if not m.any(): continue
        z = a*z0 + b*z1 + c*z2
        sub = zb[ymin:ymax+1, xmin:xmax+1]
        upd = m & (z > sub)
        sub[upd] = z[upd]
        img[ymin:ymax+1, xmin:xmax+1][upd] = C[k]
    if edges is not None:
        for a, b in edges:
            pa, pb = toscr(np.array([a, b]))
            n = int(max(abs(pb[0]-pa[0]), abs(pb[1]-pa[1]))/0.7) + 2
            ts = np.linspace(0, 1, n)
            pts = pa[None, :]*(1-ts[:, None]) + pb[None, :]*ts[:, None]
            xs = pts[:, 0].astype(int); ys = pts[:, 1].astype(int); zs = pts[:, 2]
            ok = (xs >= 1) & (xs < w-2) & (ys >= 1) & (ys < h-2)
            xs, ys, zs = xs[ok], ys[ok], zs[ok]
            vis = zs >= zb[ys, xs] - 15
            for dx in range(edge_w):
                for dy in range(edge_w):
                    img[ys[vis]+dy, xs[vis]+dx] = edge_col
    im = Image.fromarray((img*255).astype(np.uint8)).resize((W, H), Image.LANCZOS)
    def scr(p):
        q = toscr(np.array(p, float))[0]; return q[0]/ss, q[1]/ss
    return im, scr


def turbo(v):
    """Mapa de color 'turbo' aproximado (v en 0..1)."""
    v = np.clip(v, 0, 1)
    r = 0.13572138 + v*(4.61539260 + v*(-42.66032258 + v*(132.13108234 + v*(-152.94239396 + v*59.28637943))))
    g = 0.09140261 + v*(2.19418839 + v*(4.84296658 + v*(-14.18503333 + v*(4.27729857 + v*2.82956604))))
    b = 0.10667330 + v*(12.64194608 + v*(-60.58204836 + v*(110.36276771 + v*(-89.90310912 + v*27.34824973))))
    return np.clip(np.stack([r, g, b], -1), 0, 1)


def colorbar(im, x, y, h, vmax, label='von Mises (MPa)', ticks=None, wbar=28, fsize=22):
    d = ImageDraw.Draw(im)
    f = ImageFont.truetype(FONT_R, fsize); fb = ImageFont.truetype(FONT_B, fsize)
    for i in range(h):
        v = 1 - i/(h-1)
        c = tuple(int(255*t) for t in turbo(np.array([v]))[0])
        d.line([(x, y+i), (x+wbar, y+i)], fill=c)
    d.rectangle([x, y, x+wbar, y+h], outline=(60, 60, 60))
    ticks = ticks or [0, vmax*0.25, vmax*0.5, vmax*0.75, vmax]
    for t in ticks:
        yy = y + h - (t/vmax)*h
        d.line([(x+wbar, yy), (x+wbar+6, yy)], fill=(60, 60, 60), width=2)
        d.text((x+wbar+10, yy-fsize/2), f'{t:.0f}', font=f, fill=(40, 40, 40))
    d.text((x-10, y-fsize-14), label, font=fb, fill=(30, 30, 30))
