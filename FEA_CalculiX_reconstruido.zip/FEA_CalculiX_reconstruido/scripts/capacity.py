"""Capacidades (método Komatsu: área de fondo 2.557 m2 x altura) y volumen CAD del combustible."""
import json, math, os
import numpy as np

GAL = 3.785411784e-3
A_K = 2.557            # m2, estudio Komatsu
H_IN = 2.240; H_JET = 2.122; H_PICK = 0.026
RHO_F = 850.0
HERE = os.path.dirname(os.path.abspath(__file__))
_ap = os.path.join(HERE, 'areas.json')
AREAS = json.load(open(_ap if os.path.exists(_ap) else os.path.join(HERE, '..', 'out', 'areas.json')))
A_CAD = AREAS['Af'] / 1e6          # 2.5726 m2 (planta interior reconstruida)
A_REAR = AREAS['a_rear3'] / 1e6     # extensión posterior 220 mm (interior)
A_P4 = AREAS['a_reg4'] / 1e6        # extensión posterior + lateral 180 mm (interior)
# caja P1: sección interior y largo
BOX_SEC = (292*(2240-1548) + 288.7**2/2) / 1e6   # m2
BOX_LEN = 1.384
BOX_V = BOX_SEC*BOX_LEN
BOX_TOP = 1.384*0.292                            # m2 (área en planta de la caja)

MEMO = {  # valores publicados en la memoria (B0..P2-M)
    'B0': (1513, 1434, 1416), 'P1': (1805, 1713, 1695), 'P2': (1817, 1738, 1720),
    'P1-M': (1801, 1709, 1691), 'P2-M': (1813, 1733, 1716)}


def poly_area_centroid(P):
    A = 0; cx = 0; cy = 0
    for i in range(len(P)):
        x0, y0 = P[i]; x1, y1 = P[(i+1) % len(P)]
        c = x0*y1 - x1*y0; A += c; cx += (x0+x1)*c; cy += (y0+y1)*c
    A /= 2; return abs(A), cx/(6*A), cy/(6*A)


# planta interior B0 (mm, coordenadas del STEP)
def inner_foot():
    import sys; sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, '..', 'scripts'))
    from geom import offset_line, inter
    A = (570.0, 1321.0); B = (1172.0, 1040.0)
    l = offset_line(A, B, 8.0, (300, 300))
    def x_at(y): return l[0][0] + (y-l[0][1])*(l[1][0]-l[0][0])/(l[1][1]-l[0][1])
    return [(8, 8), (2284, 8), (2284, 1032), (x_at(1032), 1032), (x_at(1313), 1313), (8, 1313)]


def capacities(name):
    """Devuelve capacidades bruta / a jet / útil (gal), con método Komatsu, y combustible CAD a jet (kg, CG)."""
    d_down = {'P1': .3, 'P2': .3, 'P1-M': .3, 'P2-M': .3}.get(name, 0.0)
    d_up = {'P2': .15, 'P2-M': .15, 'P3': .16}.get(name, 0.0)
    A_ext = {'P3': A_REAR, 'P4': A_P4}.get(name, 0.0)
    box = name in ('P1', 'P1-M')
    AK = A_K + A_ext
    gross = AK*(H_IN + d_down + d_up) + (BOX_V if box else 0)
    jet = AK*(H_JET + d_down + d_up) + ((BOX_V - BOX_TOP*(H_IN-H_JET)) if box else 0)
    useful = jet - AK*H_PICK
    r = dict(gross=gross/GAL, jet=jet/GAL, useful=useful/GAL)
    if name in MEMO:
        r['memo'] = MEMO[name]
    # combustible CAD a nivel jet sensor (planta reconstruida), con CG
    foot = inner_foot()
    Af, cx, cy = poly_area_centroid(foot)
    z0 = -1000*d_down; zj = 1000*(H_JET + d_up)   # z interior del fondo y del jet sensor
    parts = [(Af*(zj-z0), cx, cy, (z0+zj)/2)]
    if name == 'P3':
        Ar, rx, ry = poly_area_centroid(AREAS['ip3']); parts.append((Ar*(zj-z0), rx, ry, (z0+zj)/2))
    if name == 'P4':
        Ar, rx, ry = poly_area_centroid(AREAS['reg4']); parts.append((Ar*(zj-z0), rx, ry, (z0+zj)/2))
    if box:
        vb = BOX_V*1e9 - BOX_TOP*1e6*(H_IN-H_JET)*1e3
        parts.append((vb, 1050.0, -146.0, 1700.0))
    V = sum(p[0] for p in parts)
    cg = [sum(p[0]*p[i] for p in parts)/V for i in (1, 2, 3)]
    r['fuel_jet_kg'] = V*1e-9*RHO_F
    r['fuel_cg'] = cg
    r['fuel_jet_m3'] = V*1e-9
    return r


if __name__ == '__main__':
    for n in ('B0', 'P1', 'P2', 'P1-M', 'P2-M', 'P3', 'P4'):
        c = capacities(n)
        print(n, {k: (round(v, 1) if isinstance(v, float) else v) for k, v in c.items() if k != 'fuel_cg'}, [round(x) for x in c['fuel_cg']])
