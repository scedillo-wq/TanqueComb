"""Análisis modal con el combustible como masa adherida a las paredes mojadas (lleno a jet sensor)."""
import sys, os, json, re
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import geom_designs as G
from fea_run import write_inp, run_ccx, JET_OFFSET
from capacity import capacities

name = sys.argv[1]; out = sys.argv[2]
tag = name.replace('-', '')
D = G.get(name)
M = np.load(os.path.join(out, f'{tag}_mesh.npz'))
nodes, cen, area, sign = M['nodes'], M['cen'], M['area'], M['sign']
elems = [(int(p), str(t), [int(x) for x in c if x > 0]) for p, t, c in zip(M['plate'], M['etype'], M['conn'])]
z_jet = D['z_roof'] - G.H2 - JET_OFFSET
cap = capacities(name)
m_f = cap['fuel_jet_kg'] / 1000.0         # t
wet = (sign != 0) & (cen[:, 2] <= z_jet)
A = area[wet].sum()
madd = np.where(wet, m_f / A, 0.0)        # t/mm2
write_inp(os.path.join(out, f'{tag}_modal.inp'), D, nodes, elems, sign, cen, modal=True, madd=madd)
dt = run_ccx(os.path.join(out, f'{tag}_modal.inp'))
txt = open(os.path.join(out, f'{tag}_modal.dat')).read()
# frecuencias
fr = []
blk = txt.split('E I G E N V A L U E   O U T P U T')[1].split('P A R T I C I P A T I O N')[0]
for line in blk.splitlines():
    p = line.split()
    if len(p) == 5 and p[0].isdigit():
        fr.append(float(p[3]))
def table(title):
    b = txt.split(title)[1]
    rows = []
    for line in b.splitlines()[1:]:
        p = line.split()
        if len(p) == 7 and p[0].isdigit():
            rows.append([float(x) for x in p[1:]])
        elif rows and (not p or not p[0].isdigit()):
            if len(rows) >= len(fr): break
    return np.array(rows[:len(fr)])
pf = table('P A R T I C I P A T I O N   F A C T O R S')
em = table('E F F E C T I V E   M O D A L   M A S S')
res = dict(name=name, freq=fr, eff_mass=em.tolist(), part=pf.tolist(), fuel_t=m_f, wet_area_m2=A/1e6, time=dt)
json.dump(res, open(os.path.join(out, f'{tag}_modal.json'), 'w'), indent=1)
print(name, ['%.2f' % f for f in fr])
for i, r in enumerate(em): print(i+1, '%.2f Hz' % fr[i], ' '.join('%.3f' % x for x in r))
