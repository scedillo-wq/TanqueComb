"""Consolida resultados de todos los diseños en runs/results.json."""
import json, os, math, sys
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from post import LCS

DES = ['B0', 'P1', 'P2', 'P1-M', 'P2-M', 'P3', 'P4']
WALL_EXT = ('EXT_POST_CARA', 'EXT_POST_CHAFLAN', 'EXT_POST_EXTERIOR', 'EXT_LAT_EXTERIOR', 'EXT_LAT_FRONTAL')
BOTTOM = ('FONDO', 'FONDO_NUEVO', 'EXT_POST_FONDO', 'EXT_FONDO')


def kind(n):
    if n.startswith('PATCH'): return 'patch'
    if n in BOTTOM: return 'fondo'
    if n.startswith('TECHO') or n in ('EXT_POST_TECHO', 'EXT_TECHO', 'CAJA_TAPA'): return 'techo'
    if n.startswith('MAMPARO') or n == 'CAJA_MAMPARO': return 'mamparo'
    if n.startswith('DIAFRAGMA') or n == 'BANDA_SUP_DIAFRAGMA': return 'diafragma'
    if n.startswith('CAJA'): return 'caja'
    if n in WALL_EXT: return 'ext'
    if n.startswith('BANDA_INF'): return 'banda_inf'
    if n.startswith('BANDA_SUP'): return 'banda_sup'
    if n.startswith('PARED'): return 'pared'
    return n


WALLISH = ('pared', 'banda_inf', 'banda_sup', 'ext')
ROWS = [
    ('Pared–fondo (esquina inferior)', lambda a, b: (a in WALLISH and b == 'fondo') or (b in WALLISH and a == 'fondo')),
    ('Mamparo–pared (filete)', lambda a, b: (a == 'mamparo' and b in WALLISH) or (b == 'mamparo' and a in WALLISH)),
    ('Mamparo–fondo (filete)', lambda a, b: {a, b} == {'mamparo', 'fondo'}),
    ('Empalme CJP banda inferior', lambda a, b: {a, b} == {'pared', 'banda_inf'}),
    ('Diafragma–pared', lambda a, b: (a == 'diafragma' and b in WALLISH) or (b == 'diafragma' and a in WALLISH)),
    ('Caja posterior–pared', lambda a, b: {a, b} == {'caja', 'pared'}),
    ('Empalme CJP banda superior', lambda a, b: (a == 'banda_sup' and b in ('pared', 'diafragma')) or (b == 'banda_sup' and a in ('pared', 'diafragma'))),
    ('Extensión–pared original', lambda a, b: (a == 'ext' and b in ('pared', 'banda_sup')) or (b == 'ext' and a in ('pared', 'banda_sup'))),
]


def main():
    out = {}
    mp = json.load(open('runs/massprops.json'))
    for d in DES:
        tag = d.replace('-', '')
        r = json.load(open(f'runs/{tag}_post.json'))
        r3 = json.load(open(f'runs/{tag}_post_3d.json'))
        assert r.get('stress_mode') == 'ps' and r3.get('stress_mode') == '3d', d
        rr = dict(name=d, ne=r['ne'], nn=r['nn'], steel_kg=r['steel_kg'], umax_1g=r['umax_1g'])
        rr['lc250_3d'] = {k: v['max_ex250'] for k, v in r3['lc'].items()}
        rr['loc250_3d'] = {k: v['loc_ex250'] for k, v in r3['lc'].items()}
        rr['comp_lc5_3d'] = r3['lc']['LC5']['by_cat']
        rr['support_150_200_3d'] = r3['lc']['LC5']['support_150_200']
        J3 = {}
        for key, val in r3['junctions'].items():
            a, b = key.split('|')
            if 'PATCH' in key: continue
            for row, f in ROWS:
                if f(kind(a), kind(b)) and val > J3.get(row, 0): J3[row] = val
        rr['junctions_3d'] = J3
        rr['lc250'] = {k: v['max_ex250'] for k, v in r['lc'].items()}
        rr['lc150'] = {k: v['max_ex150'] for k, v in r['lc'].items()}
        rr['loc250'] = {k: v['loc_ex250'] for k, v in r['lc'].items()}
        rr['support_150_200'] = r['lc']['LC5']['support_150_200']
        rr['comp_lc5'] = r['lc']['LC5']['by_cat']
        # uniones
        J = {}
        for key, val in r['junctions'].items():
            a, b = key.split('|')
            if 'PATCH' in key: continue
            ka, kb = kind(a), kind(b)
            for row, f in ROWS:
                if f(ka, kb):
                    if val > J.get(row, (0, ''))[0]: J[row] = (val, key)
        rr['junctions'] = {k: v[0] for k, v in J.items()}
        rr['junctions_where'] = {k: v[1] for k, v in J.items()}
        crit = max(rr['junctions'].values())
        rr['j_crit'] = crit
        rr['j_crit_row'] = max(rr['junctions'], key=rr['junctions'].get)
        rr['a_adm_g'] = 45.8 / crit
        # reacciones
        rf = r['rf_unit']
        def vec(step, nm): return np.array(rf[step][nm])/1e3
        rr['rf1g'] = {nm: vec(0, nm).tolist() for nm in rf[0]}
        rr['R3g_lugR'] = 3*float(np.linalg.norm(vec(0, 'RLUGR')))
        rr['R3g_lugF'] = 3*float(np.linalg.norm(vec(0, 'RLUGF')))
        rr['R3g_low'] = 3*float(vec(0, 'NLOW1')[0] + vec(0, 'NLOW2')[0])
        rr['Rz1g_sum'] = float(vec(0, 'RLUGR')[2] + vec(0, 'RLUGF')[2] + vec(0, 'NLOW1')[2] + vec(0, 'NLOW2')[2])
        # mínimo de compresión de los apoyos inferiores en todas las combinaciones
        mins = []
        maxlug = 0
        for lc, combos in LCS.items():
            for a in combos:
                for nm in ('NLOW1', 'NLOW2'):
                    fx = a[0]*vec(0, nm)[0] + a[1]*vec(1, nm)[0] + a[2]*vec(2, nm)[0]
                    mins.append(fx)
                for nm in ('RLUGR', 'RLUGF'):
                    v = a[0]*vec(0, nm) + a[1]*vec(1, nm) + a[2]*vec(2, nm)
                    maxlug = max(maxlug, float(np.linalg.norm(v)))
        rr['low_min_kN'] = float(min(mins))
        rr['lug_max_any_kN'] = maxlug
        rr['mass'] = mp[d]
        # modal
        try:
            m = json.load(open(f'runs/{tag}_modal.json'))
            rr['modal'] = m
            em = np.array(m['eff_mass']); fr = m['freq']
            mt = em[:, :3].sum(0).max()   # masa efectiva acumulada de referencia
            tot = mp[d]['total']/1000.0
            cls = {}
            for i, f in enumerate(fr):
                ex, ey, ez = em[i, :3]/tot
                if 'm1' not in cls and ey > 0.10 and ey >= max(ex, ez): cls['m1'] = (f, i+1)
                if 'm2' not in cls and ex > 0.10 and ex >= ey: cls['m2'] = (f, i+1)
                if 'm3' not in cls and (ex+ey+ez) < 0.05 and f > 0: cls['m3'] = (f, i+1)
            rr['modal_class'] = {k: v[0] for k, v in cls.items()}
            rr['modal_class_idx'] = {k: v[1] for k, v in cls.items()}
            rr['modal_ratios'] = (em[:, :3]/tot).round(3).tolist()
        except FileNotFoundError:
            rr['modal'] = None
        out[d] = rr
    json.dump(out, open('runs/results.json', 'w'), indent=1, default=float)
    # impresión
    for d, rr in out.items():
        print(f"{d:5s} LC250 " + ' '.join(f"{k}:{v:5.0f}" for k, v in rr['lc250'].items()) + f"  FS={245/rr['lc250']['LC5']:.2f}  u1g={rr['umax_1g']:.2f}  sup={rr['support_150_200']:.0f}")
        print('      loc LC5', [round(x) if isinstance(x, float) else x for x in rr['loc250']['LC5']])
        print('      comp', {k: round(v) for k, v in rr['comp_lc5'].items()})
        print('      J', {k: round(v, 1) for k, v in rr['junctions'].items()}, ' crit', round(rr['j_crit'], 1), rr['j_crit_row'])
        print(f"      R3g lugR {rr['R3g_lugR']:.0f} lugF {rr['R3g_lugF']:.0f} low {rr['R3g_low']:.0f}  Rz1g {rr['Rz1g_sum']:.2f}  lowmin {rr['low_min_kN']:.1f}")
        if rr['modal']:
            print('      f', [round(f, 2) for f in rr['modal']['freq'][:8]], rr.get('modal_class_idx'))
            print('      ratios', rr['modal_ratios'][:8])


if __name__ == '__main__':
    main()
