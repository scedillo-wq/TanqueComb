"""Post-proceso de un diseño: combinaciones LC1-LC5, componentes, uniones, reacciones, masas."""
import sys, os, json, math
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fea_run import parse_dat, surfaces, vm, principal_absmax, RHO_S, RHO_F, GACC, JET_OFFSET
import geom_designs as G

SY = 245.0


def plane_stress(S, nrm):
    """Proyecta el tensor (ne, npt, 6) al plano tangente de cada cáscara: anula s_nn y tau_nt (artefacto C3D20R)."""
    sx, sy, sz, txy, txz, tyz = [S[..., i] for i in range(6)]
    T = np.stack([np.stack([sx, txy, txz], -1), np.stack([txy, sy, tyz], -1), np.stack([txz, tyz, sz], -1)], -2)
    P = np.eye(3)[None] - nrm[:, :, None]*nrm[:, None, :]
    Tp = np.einsum('eij,epjk,ekl->epil', P, T, P)
    return np.stack([Tp[..., 0, 0], Tp[..., 1, 1], Tp[..., 2, 2], Tp[..., 0, 1], Tp[..., 0, 2], Tp[..., 1, 2]], -1)
LCS = {
    'LC1': [(1, 0, 0)],
    'LC2': [(1, 0.5, 0), (1, -0.5, 0)],
    'LC3': [(1, 0, 0.5), (1, 0, -0.5)],
    'LC4': [(2, sy*0.5, sx*0.3) for sy in (1, -1) for sx in (1, -1)],
    'LC5': [(3, 0, 0)],
}

PATCHES = None


def patch_rects():
    zc, h = G.LUG['zc'], G.LUG['half']
    R = [('y', G.YR, (G.LUG['x0'], G.LUG['x1']), (zc-h, zc+h)),
         ('y', G.YW, (G.LUG['x0'], G.LUG['x1']), (zc-h, zc+h))]
    for (y0, y1) in G.LOW:
        R.append(('x', G.XI, (y0, y1), G.LOW_Z))
    return R


def dist_to_patches(c):
    d = []
    for ax, v, (a0, a1), (z0, z1) in patch_rects():
        if ax == 'y':
            px = np.clip(c[:, 0], a0, a1); py = np.full(len(c), v); pz = np.clip(c[:, 2], z0, z1)
        else:
            px = np.full(len(c), v); py = np.clip(c[:, 1], a0, a1); pz = np.clip(c[:, 2], z0, z1)
        d.append(np.sqrt((c[:, 0]-px)**2 + (c[:, 1]-py)**2 + (c[:, 2]-pz)**2))
    return np.min(d, 0)


def junctions(conn, etype, plate, cats, names):
    """Elementos adyacentes a cada tipo de unión (nodos compartidos entre planchas distintas)."""
    node_pl = {}
    for k in range(len(conn)):
        nn = 8 if etype[k] == 'S8R' else 6
        for n in conn[k][:nn]:
            node_pl.setdefault(int(n), set()).add(int(plate[k]))
    J = {}
    for k in range(len(conn)):
        nn = 8 if etype[k] == 'S8R' else 6
        me = int(plate[k])
        for n in conn[k][:nn]:
            for o in node_pl[int(n)]:
                if o == me: continue
                key = tuple(sorted([names[me], names[o]]))
                J.setdefault(key, set()).add(k)
    return J


def main(tag, rdir):
    M = np.load(os.path.join(rdir, f'{tag}_mesh.npz'))
    D = json.load(open(os.path.join(rdir, f'{tag}_design.json')))
    plates = D['plates']; names = [p['name'] for p in plates]; cats = [p['cat'] for p in plates]
    cen, area, plate, etype, conn = M['cen'], M['area'], M['plate'], M['etype'], M['conn']
    ne = len(cen)
    steps = parse_dat(os.path.join(rdir, f'{tag}_static.dat'), ne)
    assert len(steps) == 3, len(steps)
    SS = [surfaces(st['S'], st['nip']) for st in steps]   # Z, Y, X
    MODE = os.environ.get('STRESS_MODE', 'ps')
    if MODE == 'ps':
        SS = [plane_stress(x, M['nrm']) for x in SS]
    dist = dist_to_patches(cen)
    res = dict(name=D['name'], ne=int(ne), nn=int(len(M['nodes'])))
    # --- masas / volúmenes
    tvec = np.array([plates[p]['t'] for p in plate])
    pc = np.array([cats[p] for p in plate])
    steel = area * tvec * RHO_S * 1e3   # kg
    steel_nopatch = steel  # parches son parte de la pared
    res['steel_kg'] = float(steel.sum())
    # --- combinaciones
    def comb(a):
        return a[0]*SS[0] + a[1]*SS[1] + a[2]*SS[2]
    out = {}
    for lc, combos in LCS.items():
        vmax_e = np.zeros(ne)
        for a in combos:
            v = vm(comb(a)).max(1)
            vmax_e = np.maximum(vmax_e, v)
        out[lc] = vmax_e
    res['lc'] = {}
    for lc, v in out.items():
        r = {}
        for ex in (150, 250):
            m = dist > ex
            k = int(np.argmax(np.where(m, v, -1)))
            r[f'max_ex{ex}'] = float(v[k]); r[f'loc_ex{ex}'] = [float(x) for x in cen[k]] + [names[plate[k]]]
        m = (dist > 150) & (dist <= 200)
        r['support_150_200'] = float(v[m].max()) if m.any() else None
        r['abs_max'] = float(v.max())
        # por componente (excluye 150 mm)
        comp = {}
        for c in sorted(set(pc)):
            mm = (pc == c) & (dist > 150)
            if mm.any(): comp[c] = float(v[mm].max())
        r['by_cat'] = comp
        # paredes originales vs nuevas
        res['lc'][lc] = r
    np.save(os.path.join(rdir, f'{tag}_vm_lc5{"" if MODE == "ps" else "_3d"}.npy'), out['LC5'])
    # --- uniones soldadas: rango de esfuerzo principal por 1g vertical (paso Z)
    pZ = principal_absmax(SS[0]).max(1)
    np.save(os.path.join(rdir, f'{tag}_p1g{"" if MODE == "ps" else "_3d"}.npy'), pZ)
    J = junctions(conn, etype, plate, cats, names)
    jres = {}
    for (a, b), ks in J.items():
        ks = np.array(sorted(ks))
        ks = ks[dist[ks] > 150]
        if len(ks) == 0: continue
        jres[f'{a}|{b}'] = float(pZ[ks].max())
    res['junctions'] = jres
    # --- reacciones por paso (N)
    rf = [st['RF'] for st in steps]
    res['rf_unit'] = rf
    # --- desplazamiento máximo 1g
    U = steps[0]['U']
    res['umax_1g'] = float(np.linalg.norm(U, axis=1).max())
    # --- verificación de equilibrio (paso Z): fuerza vertical total
    fz = sum(v[2] for v in rf[0].values())
    res['sum_Rz_1g_kN'] = fz/1e3
    res['stress_mode'] = MODE
    json.dump(res, open(os.path.join(rdir, f'{tag}_post{"" if MODE == "ps" else "_3d"}.json'), 'w'), indent=1)
    return res


if __name__ == '__main__':
    r = main(sys.argv[1], sys.argv[2])
    print(json.dumps({k: v for k, v in r.items() if k not in ('junctions',)}, indent=1)[:6000])
    print('JUNCTIONS')
    for k, v in sorted(r['junctions'].items(), key=lambda x: -x[1])[:40]: print(f'  {v:7.1f}  {k}')
