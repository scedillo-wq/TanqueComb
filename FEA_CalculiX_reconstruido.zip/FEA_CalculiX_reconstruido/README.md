# Modelo FEA reconstruido – tanque de combustible 980E-5

Modelos de cáscaras CalculiX 2.21 (S8R/S6, malla de 50 mm) de los siete diseños de la memoria de cálculo:
B0 (actual), P1, P2, P1-M, P2-M, P3 y P4. Mismos apoyos, cargas y criterios de la memoria (secciones 3 a 5).

## Contenido

- `inp/<diseño>_static.inp`: estático de 3 pasos unitarios (1g vertical, 1g longitudinal inercial +Y, 1g lateral inercial +X).
  Los casos LC1–LC5 se arman por superposición lineal (`scripts/post.py`).
- `inp/<diseño>_modal.inp`: análisis modal con el combustible (lleno a jet sensor) como masa adherida a las paredes mojadas.
- `scripts/`: geometría por plancha (`geom_designs.py`), malla gmsh + escritura del .inp + corrida (`fea_run.py`),
  post-proceso (`post.py`, `results.py`), modal (`modal_run.py`), capacidades (`capacity.py`), masas y CG (`massprops.py`),
  verificación de uniones de malla (`junction_check.py`), figuras (`figs.py`, `contours.py`, `viz.py`) y Excel (`export_xlsx.py`).

## Cómo repetir

```bash
pip install gmsh numpy scipy pillow matplotlib openpyxl   # y calculix-ccx 2.21
cd scripts
python3 fea_run.py P3 ../runs            # malla + estático
python3 post.py P3 ../runs               # tensión plana (corregido, sección 5.2)
STRESS_MODE=3d python3 post.py P3 ../runs   # lectura de la memoria original
python3 modal_run.py P3 ../runs          # modal (NMODES=20 para 20 modos)
```

Coordenadas en mm: x lateral (0 = cara del lado bastidor), y longitudinal (0 = cara posterior, + hacia el frente),
z vertical (0 = cara interior del fondo original). Unidades del .inp: mm, N, t, s.

Nota sobre esfuerzos: los S8R se expanden a C3D20R y en bordes y uniones aparece un esfuerzo normal espurio a través
del espesor. `post.py` proyecta el tensor al plano de la cáscara (tensión plana) antes de calcular von Mises
(ver sección 5.2 de la memoria).
